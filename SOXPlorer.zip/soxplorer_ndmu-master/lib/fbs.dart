import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

class FirebaseService {
  static final FirebaseService _instance = FirebaseService._();

  factory FirebaseService() => _instance;

  FirebaseService._();

  Future<void> initialize() async {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyCzdmO3QI1ab7BwCYQzf5fNu1HLvxiKR6A",
        appId: "1:16414755754:android:b41eee8d5edfadb8c639d3",
        messagingSenderId: "16414755754",
        projectId: "soxplorerapp",
        authDomain: "soxplorerapp.firebaseapp.com",
        storageBucket: "soxplorerapp.appspot.com",
      ),
    );
  }

  DatabaseReference get databaseRef => FirebaseDatabase.instance.reference();
}
