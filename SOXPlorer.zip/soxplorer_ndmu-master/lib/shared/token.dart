import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class SharedPreferencesHelper {
  static final StreamController<Map<String, dynamic>> _userInfoController = StreamController<Map<String, dynamic>>.broadcast();

  static Stream<Map<String, dynamic>> get userInfoStream {
    getUserInfo().then((userInfo) {
      _userInfoController.add(userInfo);
    });
    return _userInfoController.stream;
  }

  static Future<void> saveUserInfo(Map<String, dynamic> userInfo) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('user_info', jsonEncode(userInfo));
    _userInfoController.add(userInfo); // Emit the new user info
  }

  static Future<void> updateUserInfo(Map<String, dynamic> userInfo) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userInfoString = prefs.getString('user_info');
    Map<String, dynamic> userInfoMap =
        userInfoString != null ? jsonDecode(userInfoString) : {};
    userInfoMap['user'] = userInfo;
    prefs.setString('user_info', jsonEncode(userInfoMap));
    _userInfoController.add(userInfoMap); // Emit the updated user info
  }

  static Future<Map<String, dynamic>> getUserInfo() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userInfoString = prefs.getString('user_info');
    return userInfoString != null ? jsonDecode(userInfoString) : {};
  }

  static void setUserInfo(Map<String, String> map) {
    saveUserInfo(map);
  }
}