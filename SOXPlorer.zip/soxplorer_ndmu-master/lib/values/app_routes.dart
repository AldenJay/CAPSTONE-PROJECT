class AppRoutes {
  static const String loginScreen = '/login';
  static const String passwordResetScreen = '/password-reset';

  static const String touristScreen = '/tourist';
  static const String touristRegisterScreen = '/tourist/register';

  static const String businessOwnerScreen = '/business-owner';
  static const String businessOwnerRegisterScreen = '/business-owner/register';

  static const String adminScreen = '/admin';
}
