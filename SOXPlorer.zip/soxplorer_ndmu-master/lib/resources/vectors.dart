class Vectors {
  static const String businessMan = 'assets/icons/business-man.svg';
  static const String tourist = 'assets/icons/tourist.svg';
  static const String bgMarbel = 'assets/images/marbel.jpg';
  static const String blankProfile = 'assets/images/blank-avatar.png';
  static const String defaultImage = 'assets/images/default.jpg';
}