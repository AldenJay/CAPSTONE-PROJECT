import 'package:flutter/material.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';
import 'package:soxplorer/pages/business_owner_pages/my_tourist_spots.dart';
import 'package:soxplorer/pages/business_owner_pages/profile.dart';
import 'package:soxplorer/pages/business_owner_pages/reviews.dart';
import 'package:soxplorer/pages/logout.dart';

// ignore: must_be_immutable
class BusinessOwnerPage extends StatefulWidget {
  BusinessOwnerPage({Key? key}) : super(key: key) {}

  @override
  State<BusinessOwnerPage> createState() => _BusinessOwnerPageState();
}

class _BusinessOwnerPageState extends State<BusinessOwnerPage> {
  int _selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // hides leading widget
        title: const Text(
          'SOXplorer',
          style: TextStyle(
            fontSize: 30,
            color: Colors.white,
          ),
        ),
        backgroundColor: const Color.fromARGB(255, 31, 81, 255),
      ),
      body: Center(
        child: _pages.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.fromARGB(255, 31, 81, 255),
              Color.fromARGB(255, 31, 81, 255),
              Color.fromARGB(255, 31, 81, 255)
            ],
          ),
        ),
        child: SalomonBottomBar(
            currentIndex: _selectedIndex,
            selectedItemColor: const Color(0xff6200ee),
            unselectedItemColor: const Color(0xff757575),
            onTap: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            items: _navBarItems),
      ),
    );
  }
}

final _navBarItems = [
  SalomonBottomBarItem(
    icon: const Icon(Icons.upcoming, color: Colors.white),
    title: const Text("Updates"),
    selectedColor: Colors.white,
  ),
  SalomonBottomBarItem(
    icon: const Icon(Icons.reviews, color: Colors.white),
    title: const Text("Reviews"),
    selectedColor: Colors.white,
  ),
  SalomonBottomBarItem(
    icon: const Icon(Icons.person, color: Colors.white),
    title: const Text("Profile"),
    selectedColor: Colors.white,
  ),
  SalomonBottomBarItem(
    icon: const Icon(Icons.logout, color: Colors.white),
    title: const Text("Logout"),
    selectedColor: Colors.white,
  ),
];

final _pages = <dynamic>[
  const TouristSpots(),
  Reviews(),
  const ProfilePage(),
  LogoutPage()
];
