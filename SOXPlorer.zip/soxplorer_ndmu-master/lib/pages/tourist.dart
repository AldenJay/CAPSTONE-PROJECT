// create simple page for tourist
import 'package:flutter/material.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';
import 'package:soxplorer/pages/logout.dart';
import 'package:soxplorer/pages/tourist_pages/my_travel_history.dart';
import 'package:soxplorer/pages/tourist_pages/profile.dart';
import 'package:soxplorer/pages/tourist_pages/tourist_spots.dart';

class TouristPage extends StatefulWidget {
  const TouristPage({super.key});

  @override
  State<TouristPage> createState() => _TouristPageState();
}

class _TouristPageState extends State<TouristPage> {
  int _selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // hides leading widget
        title: const Text(
          'SOXplorer',
          style: TextStyle(
            fontSize: 30,
            color: Colors.white,
            // change font family
            fontFamily: 'Poppins',
          ),
        ),
        backgroundColor: 
              const Color.fromARGB(255, 31, 81, 255),
      ),
      body: Center(
        child: _pages.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.fromARGB(255, 31, 81, 255),
              Color.fromARGB(255, 31, 81, 255),
              Color.fromARGB(255, 31, 81, 255),
            ],
          ),
        ),
        child: SalomonBottomBar(
            currentIndex: _selectedIndex,
            selectedItemColor: const Color(0xff6200ee),
            unselectedItemColor: const Color(0xff757575),
            onTap: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            items: _navBarItems),
      ),
    );
  }
}

final _navBarItems = [
  SalomonBottomBarItem(
    icon: const Icon(Icons.location_on, color: Colors.white),
    title: const Text("Tourist Spots"),
    selectedColor: Colors.white,
  ),
  // history
  SalomonBottomBarItem(
    icon: const Icon(Icons.trip_origin, color: Colors.white),
    title: const Text("My Journey"),
    selectedColor: Colors.white,
  ),
  SalomonBottomBarItem(
    icon: const Icon(Icons.person, color: Colors.white),
    title: const Text("Profile"),
    selectedColor: Colors.white,
  ),
  SalomonBottomBarItem(
    icon: const Icon(Icons.logout, color: Colors.white),
    title: const Text("Logout"),
    selectedColor: Colors.white,
  ),
];

final _pages = <dynamic>[
  const TouristSpots(),
  const TravelHistory(),
  const ProfilePage(),
  LogoutPage(),
];
