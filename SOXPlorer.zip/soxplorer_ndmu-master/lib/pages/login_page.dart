import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:soxplorer/shared/token.dart';
import 'package:soxplorer/values/app_routes.dart';

import '../components/app_text_form_field.dart';
import '../resources/vectors.dart';
import '../utils/extensions.dart';

// create custom exception for unverified account of business owner
class UnverifiedAccountException implements Exception {
  final String message;

  const UnverifiedAccountException(this.message);
}

class RejectedAccountException implements Exception {
  final String message;

  const RejectedAccountException(this.message);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _collection = _firestore.collection('user_info');

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  Map<String, dynamic> fieldErrors = {};

  bool isObscure = true;

  bool isButtonDisabled() {
    return emailController.text.isEmpty || passwordController.text.isEmpty;
  }

  final FirebaseAuth _auth = FirebaseAuth.instance;
  Future<dynamic> login() async {
    try {
      // Use Firebase Authentication to sign in with email and password
      UserCredential authResult = await _auth.signInWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text,
      );

      // Get the authenticated user
      User? user = authResult.user!;

      DocumentSnapshot userRoleSnapshot = await _collection.doc(user.uid).get();

      if (userRoleSnapshot.exists) {
        Map<String, dynamic> userData =
            userRoleSnapshot.data() as Map<String, dynamic>;
        String userRole = userData['role'];

        // check if role is business owner, if business owner, check if account is verified in user_info
        if (userRole == 'business_owner') {
          if (userData['is_verified'] == false &&
              userData['is_rejected'] == false) {
            throw const UnverifiedAccountException(
                'Business owner account is not verified');
          }
          if (userData['is_rejected'] == true &&
              userData['is_verified'] == false) {
            throw const RejectedAccountException(
                'Business owner account is rejected');
          }
        }

        // convert user to map
        userData['uid'] = user.uid;
        userData['email'] = user.email;

        SharedPreferencesHelper.saveUserInfo(userData);
        emailController.clear();
        passwordController.clear();
        return userRole;
      } else {
        // it is an admin
        SharedPreferencesHelper.saveUserInfo({
          'uid': user.uid,
          'email': user.email,
          'role': 'admin',
        });
        emailController.clear();
        passwordController.clear();
        return 'admin';
      }
    } on FirebaseAuthException catch (error) {
      return error;
    } catch (error) {
      return error;
    }
  }

  void handleLogin() async {
    login().then((value) {
      if (value is String) {
        if (value == 'business_owner') {
          Navigator.pushNamed(context, AppRoutes.businessOwnerScreen);
        } else if (value == 'tourist') {
          Navigator.pushNamed(context, AppRoutes.touristScreen);
        } else if (value == 'admin') {
          Navigator.pushNamed(context, AppRoutes.adminScreen);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Unauthorized user"),
            ),
          );
        }
      } else {
        fieldErrors.clear();
        if (value is FirebaseAuthException) {
          // invalid-email
          if (value.code == 'invalid-email') {
            setState(() {
              fieldErrors = {
                'username': 'Invalid email address',
              };
            });
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("Invalid email login credentials"),
              ),
            );
          }
          _formKey.currentState?.validate();
        } else {
          if (value is UnverifiedAccountException) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text(
                    "Business owner account is not verified, please wait for admin to verify your account"),
              ),
            );
          } else if (value is RejectedAccountException) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("Business owner account is rejected"),
              ),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text("An error occured"),
              ),
            );
          }
        }
      }
    }).catchError((error) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("An error occured"),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = context.mediaQuerySize;
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Container(
                height: size.height * 0.24,
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xff1E2E3D),
                      Color(0xff152534),
                      Color(0xff0C1C2E),
                    ],
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Welcome to\nSOXplorer',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(
                      height: 6,
                    ),
                    Text(
                      'Sign in to your Account to start exploring',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AppTextFormField(
                      labelText: 'Email',
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.next,
                      validator: (value) {
                        return fieldErrors.containsKey('username')
                            ? fieldErrors['username']
                            : value!.isEmpty
                                ? 'Email is required'
                                : null;
                      },
                      controller: emailController,
                    ),
                    AppTextFormField(
                      labelText: 'Password',
                      keyboardType: TextInputType.visiblePassword,
                      textInputAction: TextInputAction.done,
                      validator: (value) {
                        return fieldErrors.containsKey('password')
                            ? fieldErrors['password']
                            : value!.isEmpty
                                ? 'Password is required'
                                : null;
                      },
                      controller: passwordController,
                      obscureText: isObscure,
                      suffixIcon: Padding(
                        padding: const EdgeInsets.only(right: 15),
                        child: IconButton(
                          onPressed: () {
                            setState(() {
                              isObscure = !isObscure;
                            });
                          },
                          style: ButtonStyle(
                            minimumSize: MaterialStateProperty.all(
                              const Size(48, 48),
                            ),
                          ),
                          icon: Icon(
                            isObscure
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    FilledButton(
                      onPressed: () {
                        handleLogin();
                      },
                      style: const ButtonStyle().copyWith(
                        backgroundColor: MaterialStateProperty.all(
                          Colors.black,
                        ),
                        foregroundColor: MaterialStateProperty.all(
                          Colors.white,
                        ),
                      ),
                      child: const Text('Login'),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Divider(
                            color: Colors.grey.shade200,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                          ),
                          child: Text(
                            'Or register as',
                            style: Theme.of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(color: Colors.black),
                          ),
                        ),
                        Expanded(
                          child: Divider(
                            color: Colors.grey.shade200,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () {
                              Navigator.pushNamed(
                                  context, AppRoutes.touristRegisterScreen);
                            },
                            style: Theme.of(context).outlinedButtonTheme.style,
                            icon: SvgPicture.asset(
                              Vectors.tourist,
                              width: 14,
                            ),
                            label: const Text(
                              'Tourist',
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () {
                              Navigator.pushNamed(context,
                                  AppRoutes.businessOwnerRegisterScreen);
                            },
                            style: Theme.of(context).outlinedButtonTheme.style,
                            icon: SvgPicture.asset(
                              Vectors.businessMan,
                              width: 14,
                            ),
                            label: const Text(
                              'Business',
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Divider(
                            color: Colors.grey.shade200,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                          ),
                          // forgot password
                          child: TextButton(
                            onPressed: () {
                              Navigator.pushNamed(
                                  context, AppRoutes.passwordResetScreen);
                            },
                            child: const Text(
                              'Forgot Password?',
                              style: TextStyle(color: Colors.black),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Divider(
                            color: Colors.grey.shade200,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
