import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';
import 'package:http/http.dart' as http;

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _user_info_collection =
    _firestore.collection('user_info');

// ignore: must_be_immutable
class BusinessAccountForApproval extends StatefulWidget {
  const BusinessAccountForApproval({super.key});

  @override
  State<BusinessAccountForApproval> createState() =>
      _BusinessAccountForApprovalState();
}

class _BusinessAccountForApprovalState
    extends State<BusinessAccountForApproval> {
  Future<List<dynamic>> touristSpots = Future<List<dynamic>>.value([]);

  Future<List<dynamic>> getBusinessAccountForApproval() async {
    await Future.delayed(const Duration(seconds: 1));
    // use the collection reference to get all documents
    // filter the documents by the owner
    // QuerySnapshot querySnapshot =
    //     await _user_info_collection.where('owner', isEqualTo: owner).get();

    // filter the documents by the role which is business_owner, is_rejected is false and is_verified is false
    QuerySnapshot querySnapshot = await _user_info_collection
        .where('role', isEqualTo: 'business_owner')
        .where('is_rejected', isEqualTo: false)
        .where('is_verified', isEqualTo: false)
        .get();

    List<dynamic> response = [];
    for (var doc in querySnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      data['id'] = doc.id; // Add the document ID to the data
      response.add(data);
    }
    return response;
  }

  @override
  void initState() {
    super.initState();
    owner = getOwner();
    touristSpots = getBusinessAccountForApproval();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: BusinessList(touristSpots: touristSpots),
      ),
    );
  }

  String owner = '';

  String getOwner() {
    SharedPreferencesHelper.getUserInfo().then((value) {
      setState(() {
        owner = value['uid'];
      });
    });
    return owner;
  }
}

// ignore: must_be_immutable
class BusinessList extends StatefulWidget {
  Future<List<dynamic>> touristSpots;

  BusinessList({Key? key, required this.touristSpots}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _BusinessListState createState() => _BusinessListState();
}

class _BusinessListState extends State<BusinessList> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: widget.touristSpots,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          // return Text('Error: ${snapshot.error}');
          if (snapshot.error is DioException) {
            final res = (snapshot.error as DioException).response;
            if (res?.statusCode == 401) {
              return const Center(
                child: Text('Unauthorized'),
              );
            } else if (res?.statusCode == 403) {
              return Center(
                child: Text(res?.data['detail']),
              );
            }
          }
          return const Center(
            child: Text('Failed to load tourist spots'),
          );
        } else {
          return ListView.builder(
            itemCount: snapshot.data == null ? 0 : snapshot.data!.length,
            itemBuilder: (context, index) {
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: Image.asset(Vectors.blankProfile).image,
                    maxRadius: 25,
                  ),
                  title: Text(snapshot.data![index]['name']),
                  subtitle: Text(snapshot.data![index]['username']),
                  // add two action buttons
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // add preview button here to preview the permit
                      IconButton(
                        onPressed: () {
                          var image = Vectors.defaultImage;
                          if (snapshot.data![index].containsKey('permit')) {
                            image = snapshot.data![index]['permit'];
                          }
                          bool isImageValid = true;
                          // check if image is null or empty
                          if (image == '') {
                            image = Vectors.defaultImage;
                            isImageValid = false;
                          } else {
                            validateImage(image).then((value) {
                              if (!value) {
                                image = Vectors.defaultImage;
                                isImageValid = false;
                              }
                            });
                          }
                          // show a dialog
                          showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                title: const Text('Permit'),
                                content: isImageValid
                                    ? Image.network(
                                        image,
                                        fit: BoxFit.cover,
                                      )
                                    : Image.asset(
                                        image,
                                        fit: BoxFit.cover,
                                      ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      // update the is_rejected to true, set is_verified to false
                                      // update the user_info collection
                                      try {
                                        _user_info_collection
                                            .doc(snapshot.data![index]['id'])
                                            .update({
                                          'is_verified': false,
                                          'is_rejected': true,
                                        });
                                        sendEmail(
                                          snapshot.data![index]['email'],
                                          'Account Rejected',
                                          'Your account has been rejected due to invalid permit',
                                        );
                                        // show a snackbar
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                            backgroundColor: Colors.red,
                                            content: Text('Account rejected'),
                                          ),
                                        );
                                        // refresh the list
                                        setState(() {
                                          // remove the item from the list
                                          snapshot.data!.removeAt(index);
                                        });
                                      } catch (error) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                            content:
                                                Text('Something went wrong'),
                                          ),
                                        );
                                      }
                                      Navigator.pop(context);
                                    },
                                    child: const Text('Reject',
                                        style: TextStyle(color: Colors.red)),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      // update the is_verified to true, set is_rejected to false
                                      // update the user_info collection
                                      try {
                                        _user_info_collection
                                            .doc(snapshot.data![index]['id'])
                                            .update({
                                          'is_verified': true,
                                          'is_rejected': false,
                                        });
                                        sendEmail(
                                          snapshot.data![index]['email'],
                                          'Account Approved',
                                          'Your account has been approved and verified, you can now login to your account',
                                        );
                                        // show a snackbar
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                            backgroundColor: Colors.green,
                                            content: Text('Account verified'),
                                          ),
                                        );
                                        // refresh the list
                                        setState(() {
                                          // remove the item from the list
                                          snapshot.data!.removeAt(index);
                                        });
                                      } catch (error) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                            content:
                                                Text('Something went wrong'),
                                          ),
                                        );
                                      }
                                      Navigator.pop(context);
                                    },
                                    child: const Text('Approve'),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                        icon: const Icon(
                          Icons.preview,
                          color: Color.fromARGB(255, 4, 248, 20),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }
      },
    );
  }

  Future<bool> validateImage(String imageUrl) async {
    try {
      final response = await http.head(Uri.parse(imageUrl));

      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  Map<String, dynamic> fieldErrors = {};
  Future<Map<String, dynamic>> handleUpdateTouristSpot(data) async {
    try {
      await _user_info_collection.doc(data['id']).update({
        'name': data['name'],
        'description': data['description'],
        'address': data['address'],
      });

      // Fetch the updated data from Firestore
      final DocumentSnapshot updatedDoc =
          await _user_info_collection.doc(data['id']).get();
      Map<String, dynamic> result = updatedDoc.data() as Map<String, dynamic>;
      result['id'] = data['id'];
      return result;
    } catch (error) {
      return {'error': 'Something went wrong'};
    }
  }

  void sendEmail(param0, String s, String t) async {
    // Replace the placeholders with your email and password
    const String username = 'soxplorer12@gmail.com';
    const String password = 'hlxl sndp oelw lurl';

    // Create an SMTP client configuration
    final smtpServer = gmail(username, password);

    // Create the message to be sent
    final message = Message()
      ..from = const Address(username, 'SoXplorer')
      ..recipients.add(param0) //recipent email
      ..subject = s //subject of the email
      ..text = t; //body of the email

    try {
      // Send the email
      final sendReport = await send(message, smtpServer);

      print('Message sent: ${sendReport.toString()}');
    } catch (e) {
      print('Error sending email: $e');
    }
  }
}
