// ignore_for_file: prefer_interpolation_to_compose_strings

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:intl/intl.dart';
import 'package:soxplorer/pages/business_owner_pages/tourist_spot_form.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _bo_accounts_collection =
    _firestore.collection('user_info');

// ignore: must_be_immutable
class Tourists extends StatefulWidget {
  const Tourists({super.key});

  @override
  State<Tourists> createState() => _TouristsState();
}

class _TouristsState extends State<Tourists> {
  Future<List<dynamic>> touristSpots = Future<List<dynamic>>.value([]);

  Future<List<dynamic>> getTourists() async {
    await Future.delayed(const Duration(seconds: 1));
    // use the collection reference to get all documents
    // filter the documents by the owner
    QuerySnapshot querySnapshot =
        await _bo_accounts_collection.where('role', isEqualTo: 'tourist').get();
    List<dynamic> response = [];
    for (var doc in querySnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      data['id'] = doc.id; // Add the document ID to the data
      response.add(data);
    }
    return response;
  }

  @override
  void initState() {
    super.initState();
    owner = getOwner();
    touristSpots = getTourists();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: BusinessList(touristSpots: touristSpots),
      ),
    );
  }

  String owner = '';

  String getOwner() {
    SharedPreferencesHelper.getUserInfo().then((value) {
      setState(() {
        owner = value['uid'];
      });
    });
    return owner;
  }
}

// ignore: must_be_immutable
class BusinessList extends StatefulWidget {
  Future<List<dynamic>> touristSpots;

  BusinessList({Key? key, required this.touristSpots}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _BusinessListState createState() => _BusinessListState();
}

class _BusinessListState extends State<BusinessList> {
  var dio = Dio();

  TextEditingController nameController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController addressController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: widget.touristSpots,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          // return Text('Error: ${snapshot.error}');
          if (snapshot.error is DioException) {
            final res = (snapshot.error as DioException).response;
            if (res?.statusCode == 401) {
              return const Center(
                child: Text('Unauthorized'),
              );
            } else if (res?.statusCode == 403) {
              return Center(
                child: Text(res?.data['detail']),
              );
            }
          }
          return const Center(
            child: Text('Failed to load tourist spots'),
          );
        } else {
          return ListView.builder(
            itemCount: snapshot.data == null ? 0 : snapshot.data!.length,
            itemBuilder: (context, index) {
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: Image.asset(Vectors.blankProfile).image,
                    maxRadius: 25,
                  ),
                  title: Text(snapshot.data![index]['username']),
                  subtitle: Text("Birthday: " +
                      DateFormat('MMM d, y').format(
                          DateTime.parse(snapshot.data![index]['birthday']))),

                  // add two action buttons
                ),
              );
            },
          );
        }
      },
    );
  }
}
