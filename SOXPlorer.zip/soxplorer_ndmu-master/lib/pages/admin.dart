// create simple page for admin
import 'package:flutter/material.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';
import 'package:soxplorer/pages/admin/approval.dart';
import 'package:soxplorer/pages/admin/bo_accounts.dart';
import 'package:soxplorer/pages/admin/tourist_accounts.dart';
import 'package:soxplorer/pages/logout.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  int _selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false, // hides leading widget
        title: const Text(
          'SOXplorer',
          style: TextStyle(
            fontSize: 30,
            color: Colors.white,
          ),
        ),
        backgroundColor: const Color.fromARGB(255, 31, 81, 255),
      ),
      body: Center(
        child: _pages.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.fromARGB(255, 31, 81, 255),
              Color.fromARGB(255, 31, 81, 255),
              Color.fromARGB(255, 31, 81, 255),
            ],
          ),
        ),
        child: SalomonBottomBar(
            currentIndex: _selectedIndex,
            selectedItemColor: const Color(0xff6200ee),
            unselectedItemColor: const Color(0xff757575),
            onTap: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            items: _navBarItems),
      ),
    );
  }
}

final _navBarItems = [
  SalomonBottomBarItem(
    icon: const Icon(Icons.approval, color: Colors.white),
    title: const Text("Approval"),
    selectedColor: Colors.white,
  ),
  SalomonBottomBarItem(
    icon: const Icon(Icons.supervised_user_circle, color: Colors.white),
    title: const Text("Tourists"),
    selectedColor: Colors.white,
  ),
  SalomonBottomBarItem(
    icon: const Icon(Icons.verified_user_outlined, color: Colors.white),
    title: const Text("Business Owners"),
    selectedColor: Colors.white,
  ),
  SalomonBottomBarItem(
    icon: const Icon(Icons.logout, color: Colors.white),
    title: const Text("Logout"),
    selectedColor: Colors.white,
  ),
];

final _pages = <dynamic>[
  const BusinessAccountForApproval(),
  const Tourists(),
  const BusinessOwners(),
  LogoutPage()
];
