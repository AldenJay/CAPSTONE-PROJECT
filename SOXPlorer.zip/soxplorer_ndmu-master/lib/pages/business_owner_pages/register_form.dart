import 'dart:io';

import 'package:bottom_picker/bottom_picker.dart';
import 'package:bottom_picker/resources/arrays.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:soxplorer/components/app_text_form_field.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/utils/extensions.dart';
import 'package:file_picker/file_picker.dart';
import 'package:soxplorer/values/app_constants.dart';

class RegisterFormBusinessOwner extends StatefulWidget {
  const RegisterFormBusinessOwner({super.key});

  @override
  State<RegisterFormBusinessOwner> createState() =>
      _RegisterFormBusinessOwnerState();
}

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _collection = _firestore.collection('user_info');

class _RegisterFormBusinessOwnerState extends State<RegisterFormBusinessOwner> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController birthdayController = TextEditingController();
  TextEditingController touristSpotName = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  bool isObscure = true;

  final _formKey = GlobalKey<FormState>();
  Map<String, dynamic> fieldErrors = {};

  final FirebaseAuth _auth = FirebaseAuth.instance;
  Future<dynamic> register() async {
    try {
      final UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text,
      );
      final User? user = userCredential.user;
      if (user != null) {
        await _collection.doc(user.uid).set({
          'username': usernameController.text,
          'name': nameController.text,
          'birthday': birthdayController.text,
          'email': emailController.text,
          'tourist_spot_name': touristSpotName.text,
          'category': selectedCategory,
          'address': addressController.text,
          'role': 'business_owner',
          'is_verified': false,
          'is_rejected': false,
        });
        final String fileName = permit.path.split('/').last;
        final Reference firebaseStorageRef =
            FirebaseStorage.instance.ref().child(fileName);
        final UploadTask uploadTask = firebaseStorageRef.putFile(permit);
        final TaskSnapshot taskSnapshot = await uploadTask;
        final String url = await taskSnapshot.ref.getDownloadURL();
        await _collection.doc(user.uid).update({
          'permit': url,
        });
        return userCredential;
      }
      return userCredential;
    } on FirebaseAuthException catch (e) {
      return e;
    }
  }

  List<String> categories = [
    '-None-',
    'General Location',
    'Accommodation',
    'Restaurant and Food',
    'Activity-based',
    'Photography',
    'Others',
  ];

  String? selectedCategory = '-None-';

  File permit = File('');
  Future<void> uploadFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'png'],
    );

    if (result != null) {
      final path = result.files.single.path!;
      final oldFile = File(path);

      // Create a timestamp
      final timestamp = DateTime.now().millisecondsSinceEpoch;

      // Create a new file path with the timestamp
      final directory = oldFile.parent;
      final newPath =
          '${directory.path}/file_$timestamp.${oldFile.path.split('.').last}';

      // Rename the file
      final newFile = await oldFile.rename(newPath);

      setState(() {
        permit = newFile;
      });
    }
  }

  void handleBusinessOwnerRegistration() async {
    setState(() {
      fieldErrors = {};
    });
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );
    final response = await register();

    // clear fieldErrors
    setState(() {
      fieldErrors = {};
    });
    if (response is FirebaseAuthException) {
      setState(() {
        fieldErrors = {
          'email': response.code == 'invalid-email'
              ? 'Email is invalid'
              : response.code == 'email-already-in-use'
                  ? 'Email is already in use'
                  : response.code == 'missing-email'
                      ? 'Email is missing'
                      : null,
          'password': response.code == 'weak-password'
              ? 'Password is too weak'
              : response.code == 'missing-password'
                  ? 'Password is missing'
                  : null,
        };
      });
      _formKey.currentState?.validate();
    } else {
      setState(() {
        fieldErrors = {};
      });
      // navigate to login page
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Account created successfully'),
          backgroundColor: Colors.green,
        ),
      );
      // ignore: use_build_context_synchronously
    }
    _formKey.currentState?.validate();

    // ignore: use_build_context_synchronously
    Navigator.of(context).pop();
    // ignore: use_build_context_synchronously
    Navigator.of(context).pushNamed('/login');
  }

  @override
  Widget build(BuildContext context) {
    final size = context.mediaQuerySize;
    return Scaffold(
        body: SingleChildScrollView(
            child: Column(children: [
      Container(
        height: size.height * 0.24,
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xff1E2E3D),
              Color(0xff152534),
              Color(0xff0C1C2E),
            ],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Register\nBusiness Account',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(
              height: 6,
            ),
            Text(
              'Sign in to your Account to start exploring',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
      Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      const SizedBox(height: 16),
                      AppTextFormField(
                        labelText: 'Username',
                        controller: usernameController,
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your username'
                              : value.length < 3
                                  ? 'Username should be at least 3 characters'
                                  : null;
                        },
                      ),
                      AppTextFormField(
                        labelText: 'Email',
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: TextInputAction.next,
                        validator: (value) {
                          return fieldErrors.containsKey('email')
                              ? fieldErrors['email']
                              : AppConstants.emailRegex.hasMatch(value!)
                                  ? null
                                  : 'Please enter a valid email';
                        },
                        onChanged: (value) {
                          _formKey.currentState?.validate();
                        },
                      ),
                      AppTextFormField(
                        labelText: 'Name',
                        controller: nameController,
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your name'
                              : null;
                        },
                      ),
                      AppTextFormField(
                          readOnly: true,
                          labelText: 'Birthday',
                          controller: birthdayController,
                          keyboardType: TextInputType.datetime,
                          textInputAction: TextInputAction.next,
                          validator: (value) {
                            return value == null || value.isEmpty
                                ? 'Please enter your birthday'
                                : null;
                          },
                          suffixIcon: Padding(
                            padding: const EdgeInsets.only(right: 15),
                            child: IconButton(
                              onPressed: () {
                                _openDatePicker(context);
                              },
                              style: ButtonStyle(
                                minimumSize: MaterialStateProperty.all(
                                  const Size(48, 48),
                                ),
                              ),
                              icon: const Icon(
                                Icons.calendar_today_outlined,
                                color: Colors.black,
                              ),
                            ),
                          )),
                      AppTextFormField(
                        labelText: 'Tourist Spot Name',
                        controller: touristSpotName,
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your tourist spot name'
                              : null;
                        },
                      ),
                      DropdownButtonFormField<String>(
                        decoration: const InputDecoration(
                          labelText: 'Category',
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                        ),
                        value: selectedCategory,
                        validator: (value) {
                          return value!.isEmpty
                              ? 'Category is required'
                              : value == '-None-'
                                  ? 'Category is required'
                                  : null;
                        },
                        icon: const Icon(Icons.arrow_drop_down),
                        iconSize: 24,
                        elevation: 16,
                        style: const TextStyle(color: Colors.black),
                        onChanged: (String? newValue) {
                          setState(() {
                            selectedCategory = newValue;
                          });
                        },
                        items: categories
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value,
                                style: const TextStyle(color: Colors.black)),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 10),
                      AppTextFormField(
                        labelText: 'Address',
                        controller: addressController,
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your address'
                              : null;
                        },
                      ),
                      AppTextFormField(
                        labelText: 'Password',
                        keyboardType: TextInputType.visiblePassword,
                        textInputAction: TextInputAction.done,
                        controller: passwordController,
                        obscureText: isObscure,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your password'
                              : value.length < 6
                                  ? 'Password should be at least 6 characters'
                                  : fieldErrors.containsKey('password')
                                      ? fieldErrors['password']
                                      : null;
                        },
                        suffixIcon: Padding(
                          padding: const EdgeInsets.only(right: 15),
                          child: IconButton(
                            onPressed: () {
                              setState(() {
                                isObscure = !isObscure;
                              });
                            },
                            style: ButtonStyle(
                              minimumSize: MaterialStateProperty.all(
                                const Size(48, 48),
                              ),
                            ),
                            icon: Icon(
                              isObscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      AppTextFormField(
                        labelText: 'Confirm Password',
                        keyboardType: TextInputType.visiblePassword,
                        textInputAction: TextInputAction.done,
                        controller: confirmPasswordController,
                        obscureText: isObscure,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your password'
                              : value != passwordController.text
                                  ? 'Passwords do not match'
                                  : null;
                        },
                        suffixIcon: Padding(
                          padding: const EdgeInsets.only(right: 15),
                          child: IconButton(
                            onPressed: () {
                              setState(() {
                                isObscure = !isObscure;
                              });
                            },
                            style: ButtonStyle(
                              minimumSize: MaterialStateProperty.all(
                                const Size(48, 48),
                              ),
                            ),
                            icon: Icon(
                              isObscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      // preview of permit in filename only, use text
                      Text(
                        permit.path.split('/').last == ''
                            ? 'No permit uploaded'
                            : permit.path.split('/').last,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () {
                                uploadFile();
                              },
                              // change background color
                              style:
                                  Theme.of(context).outlinedButtonTheme.style,
                              icon: const Icon(
                                Icons.upload_file,
                                color: Colors.black,
                              ),
                              label: const Text(
                                'Upload Permit',
                                style: TextStyle(
                                    color: Color.fromARGB(255, 99, 33, 33)),
                              ),
                            ),
                          ),
                        ],
                      ),
                      // show allowed file types
                      const Text(
                        'Allowed file types: jpg, png',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 12,
                        ),
                      ),
                      // button
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () {
                                // clear fieldErrors
                                setState(() {
                                  fieldErrors = {};
                                });
                                if (!_formKey.currentState!.validate()) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content:
                                          Text('Please fill all the fields'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                  return;
                                }
                                // check if permit is uploaded
                                if (permit.path.isEmpty) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                          'Please upload your permit first'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                  return;
                                }
                                // check if password and confirm password match
                                if (passwordController.text !=
                                    confirmPasswordController.text) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                          'Passwords do not match. Please try again'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                  return;
                                }
                                handleBusinessOwnerRegistration();
                              },
                              // change background color
                              style:
                                  Theme.of(context).outlinedButtonTheme.style,
                              icon: SvgPicture.asset(
                                Vectors.businessMan,
                                width: 14,
                              ),
                              label: const Text(
                                'Register Account',
                                style: TextStyle(
                                    color: Color.fromARGB(255, 99, 33, 33)),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                )
              ]))
    ])));
  }

  void _openDatePicker(BuildContext context) {
    BottomPicker.date(
      title: 'Set your Birthday',
      dateOrder: DatePickerDateOrder.dmy,
      initialDateTime: DateTime(1996, 10, 22),
      maxDateTime: DateTime(2024),
      minDateTime: DateTime(1980),
      pickerTextStyle: const TextStyle(
        color: Colors.blue,
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      titleStyle: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 15,
        color: Colors.blue,
      ),
      onSubmit: (date) {
        setState(() {
          birthdayController.text = date.toString().split(' ')[0];
        });
      },
      bottomPickerTheme: BottomPickerTheme.plumPlate,
    ).show(context);
  }
}
