import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import 'package:soxplorer/pages/tourist_pages/view_map.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';
import 'package:http/http.dart' as http;

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
final CollectionReference _reviews_and_ratings =
    _firestore.collection('reviews_and_ratings');
final CollectionReference _travel_history =
    _firestore.collection('travel_history');
final CollectionReference _tourist_sport_collection =
    _firestore.collection('tourist_spots');

class CommentsAndRatingsPage extends StatefulWidget {
  final dynamic data; // You can pass the necessary data as a parameter

  CommentsAndRatingsPage({Key? key, required this.data}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _CommentsAndRatingsPageState createState() => _CommentsAndRatingsPageState();
}

class _CommentsAndRatingsPageState extends State<CommentsAndRatingsPage> {
  List<dynamic> commentsAndRatings = [];
  double averageRating = 0.0;
  TextEditingController commentController = TextEditingController();
  Future<List<dynamic>> touristSpots = Future<List<dynamic>>.value([]);
  Future<List<dynamic>> getTouristSpots() async {
    await Future.delayed(const Duration(seconds: 1));
    // use the collection reference to get all documents
    // filter the documents by the owner
    QuerySnapshot querySnapshot = await _tourist_sport_collection
        .where('owner', isEqualTo: widget.data['id'])
        .get();
    return querySnapshot.docs;
  }

  loadCommentsAndRatings() async {
    // filter comments and ratings by id
    QuerySnapshot querySnapshot = await _reviews_and_ratings
        .where('tourist_spot', isEqualTo: widget.data['id'])
        .orderBy('created', descending: true)
        .get();

    List<DocumentSnapshot> commentsAndRatings = querySnapshot.docs;
    // put to the top the comments and ratings of the current user
    for (int i = 0; i < commentsAndRatings.length; i++) {
      if (commentsAndRatings[i]['tourist_username'] == user) {
        // remove from the list
        commentsAndRatings.removeAt(i);
        // add to the top
        commentsAndRatings.insert(0, querySnapshot.docs[i]);
      }
    }
    setState(() {
      this.commentsAndRatings = commentsAndRatings;
    });
    // calculate average rating
    int totalComments = 0;
    double sum = 0;
    for (int i = 0; i < commentsAndRatings.length; i++) {
      // convert to double
      // include only not zero ratings
      if (double.parse(commentsAndRatings[i]['rating'].toString()) != 0) {
        sum += double.parse(commentsAndRatings[i]['rating'].toString());
        totalComments++;
      }
    }
    // averageRating = sum ~/ commentsAndRatings.length;
    // provide even the decimal places do not round off
    averageRating = sum / totalComments.toDouble();
    // make it 1 decimal place
    averageRating = double.parse(averageRating.toStringAsFixed(1));
    averageRating = averageRating.isNaN ? 0.0 : averageRating;
  }

  loadFavorites() async {
    // filter comments and ratings by id
    QuerySnapshot querySnapshot = await _travel_history
        .where('tourist_spot', isEqualTo: widget.data['id'])
        .where('tourist_username', isEqualTo: user)
        .get();
    setState(() {
      isFavourite = querySnapshot.docs.isNotEmpty;
    });
  }

  bool? isImageValid;
  String user = '';
  String role = '';
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 1), () async {
      if (widget.data['image'] == null) {
        setState(() {
          isImageValid = false;
        });
        return;
      }
      validateImage(widget.data['image']).then((value) {
        setState(() {
          isImageValid = value;
        });
      }).catchError((error) {
        setState(() {
          isImageValid = false;
        });
      });
    });
    loadCommentsAndRatings();
    touristSpots = getTouristSpots();
    // get username from shared preferences
    SharedPreferencesHelper.getUserInfo().then(
      (value) => setState(() {
        user = value['username'];
        role = value['role'];
        loadFavorites();

        // find the comment of the current user and put it on the comment field
        _reviews_and_ratings
            .where('tourist_spot', isEqualTo: widget.data['id'])
            .where('tourist_username', isEqualTo: user)
            .get()
            .then((value) {
          if (value.docs.isNotEmpty) {
            hasComment = true;
            // put the comment to the comment field
            commentController.text = value.docs.first['review'];
            // put the rating to the rating field
            setState(() {
              selectedRating = value.docs.first['rating'];
            });
          }
        });
      }),
    );
  }

  int selectedRating = 0; // update this value when user taps
  bool hasComment = false;
  Future<dynamic> comment() {
    // save comment and rating to database
    // validate at least one of the two is not empty
    if (commentController.text == '' && selectedRating == 0) {
      return Future.error('Please enter your comment or rating.');
    }
    return _reviews_and_ratings
        .where('tourist_spot', isEqualTo: widget.data['id'])
        .where('tourist_username', isEqualTo: user)
        .get()
        .then((value) {
      if (value.docs.isNotEmpty) {
        hasComment = true;
        // update
        return _reviews_and_ratings
            .doc(value.docs.first.id)
            .update({
              'review': commentController.text != ''
                  ? commentController.text
                  : value.docs.first['review'],
              'rating': selectedRating != 0
                  ? selectedRating
                  : value.docs.first['rating'],
              'created': DateTime.now(),
            })
            .then((value) => value)
            .catchError((error) {
              // show error message
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(error.toString()),
                ),
              );
            });
      } else {
        hasComment = true;
        // create
        return _reviews_and_ratings
            .add({
              'tourist_spot': widget.data['id'],
              'tourist_username': user,
              'review':
                  commentController.text != '' ? commentController.text : '',
              'rating': selectedRating,
              'created': DateTime.now(),
            })
            .then((value) => value)
            .catchError((error) {
              // show error message
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(error.toString()),
                ),
              );
            });
      }
    });
  }

  void handleComment() {
    comment().then((value) {
      // show success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Comment submitted.'),
        ),
      );
      loadCommentsAndRatings();
      // clear comment field
      commentController.clear();
      // clear rating
      setState(() {
        selectedRating = 0;
      });
    }).catchError((error) {
      // show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(error.toString()),
        ),
      );
    });
  }

  bool isFavourite = false;

  void handleAddToFavourites() {
    // check if already in travel history, if yes, remove
    // do not use isFavourite because it is not updated yet
    _travel_history
        .where('tourist_spot', isEqualTo: widget.data['id'])
        .where('tourist_username', isEqualTo: user)
        .get()
        .then((value) {
      if (value.docs.isNotEmpty) {
        // remove from travel history
        _travel_history
            .doc(value.docs.first.id)
            .delete()
            .then((value) => setState(() {
                  isFavourite = false;
                }))
            .catchError((error) {
          // show error message
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(error.toString()),
            ),
          );
        });
      } else {
        // add to travel history
        _travel_history
            .add({
              'tourist_spot': widget.data['id'],
              'tourist_username': user,
              'image': widget.data['image'],
              'tourist_spot_name': widget.data['tourist_spot_name'],
              'category': widget.data['category'],
              'address': widget.data['address'],
              'created': DateTime.now(),
            })
            .then((value) => setState(() {
                  isFavourite = true;
                }))
            .catchError((error) {
              // show error message
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(error.toString()),
                ),
              );
            });
      }
    });
  }

  Future<bool> validateImage(String imageUrl) async {
    try {
      final response = await http.head(Uri.parse(imageUrl));

      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  showImage() {
    if (widget.data['image'] == null || isImageValid == null) {
      if (isImageValid == false) {
        return Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          clipBehavior: Clip.antiAlias,
          child: Image.asset(
            Vectors.defaultImage,
            height: 200,
            fit: BoxFit.cover,
          ),
        );
      }
      return Center(
        child: Shimmer.fromColors(
          baseColor: const Color.fromARGB(255, 215, 215, 215),
          highlightColor: const Color.fromARGB(255, 150, 150, 147),
          child: Container(
            height: 200, // Adjust this height to match your design requirements
            width: double.infinity, // Set width to cover the entire screen
            color: Colors.white,
          ),
        ),
      );
    }
    if (isImageValid!) {
      return Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        clipBehavior: Clip.antiAlias,
        child: Image.network(
          widget.data['image'],
          height: MediaQuery.of(context).size.height * 0.3,
          fit: BoxFit.cover,
        ),
      );
    } else {
      // Blank image
      return Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15.0),
        ),
        clipBehavior: Clip.antiAlias,
        child: Image.asset(
          Vectors.defaultImage,
          height: 200,
          fit: BoxFit.cover,
        ),
      );
    }
  }

  validateCategory(category) {
    if (category == null) {
      return '';
    }
    return category;
  }

  @override
  Widget build(BuildContext context) {
    // Implement the UI for displaying comments and ratings using widget.data
    return DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Posts and Comments',
                style: TextStyle(color: Colors.black, fontSize: 20)),
            bottom: const TabBar(
              indicatorColor: Color.fromARGB(255, 31, 81, 255),
              // change font color on selected tab
              labelColor: Color.fromARGB(255, 31, 81, 255),
              // isScrollable: true,
              tabs: [
                Tab(
                  icon: Icon(Icons.location_on),
                  child: Flexible(
                    child: Text(
                      'Tourist Spot',
                      style: TextStyle(
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),     
                ),
                Tab(
                  icon: Icon(Icons.list),
                  child: Flexible(
                    child: Text(
                      'Posts',
                      style: TextStyle(
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                Tab(
                  icon: Icon(Icons.comment),
                  child: Flexible(
                    child: Text(
                      'Comments & Ratings',
                      style: TextStyle(
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              SingleChildScrollView(
                child: Column(
                  children: [
                    showImage(),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Text(
                          widget.data['tourist_spot_name']
                              .toString()
                              .toUpperCase(),
                          style: const TextStyle(
                            color: Colors.red,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        // padding on left only
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Text(
                          validateCategory(widget.data['category']),
                          style: const TextStyle(
                            color: Color.fromARGB(255, 75, 74, 74),
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 10),
                    // add toggleable heart icon here

                    // left align review
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        // padding on left only
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Text(
                          'Average Rating: $averageRating',
                          style: const TextStyle(
                            color: Color.fromARGB(255, 75, 74, 74),
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),

                    // show address, description
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        // padding on left only
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Text(
                          "Address: ${widget.data['address']}",
                          style: const TextStyle(
                            color: Color.fromARGB(255, 75, 74, 74),
                            fontSize: 12, // Decrease font size
                            fontWeight:
                                FontWeight.w400, // Make font weight thinner
                          ),
                        ),
                      ),
                    ),
                    // add icon button to view map
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        // padding on left only
                        padding: const EdgeInsets.only(left: 15.0),
                        child: TextButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => GoogleMapsIframe(
                                  location: widget.data['address'],
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.map),
                          label: const Text('View map'),
                        ),
                      ),
                    ),
                    role == 'tourist'
                        ? Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: ElevatedButton.icon(
                                icon: Icon(
                                  isFavourite == false
                                      ? Icons.add
                                      : Icons.remove,
                                  color:
                                      isFavourite ? Colors.red : Colors.green,
                                ),
                                label: Text(
                                  isFavourite
                                      ? 'Remove from travel history'
                                      : 'Add to travel history',
                                  style: TextStyle(
                                    color:
                                        isFavourite ? Colors.red : Colors.green,
                                  ),
                                ),
                                onPressed: () {
                                  handleAddToFavourites();
                                },
                              ),
                            ),
                          )
                        : Container(),
                  ],
                ),
              ),
              SingleChildScrollView(
                child: SizedBox(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.8,
                    child: BusinessList(touristSpots: touristSpots)),
              ),
              SingleChildScrollView(
                child: Column(
                  children: [
                    // comment form
                    // show only if role is tourist and has no comment yet
                    role == 'tourist' && hasComment == false
                        ? const SizedBox(height: 10)
                        : Container(),
                    role == 'tourist' && hasComment == false
                        ? Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(25.0),
                                child: Column(
                                  // add padding to the form
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: List.generate(5, (index) {
                                        int starValue =
                                            index + 1; // 1-based rating
                                        return GestureDetector(
                                          onTap: () {
                                            // if user double taps on the same star, reset rating
                                            if (starValue == selectedRating) {
                                              starValue = 0;
                                            }
                                            setState(() {
                                              selectedRating = starValue;
                                            });
                                          },
                                          child: Icon(
                                            Icons.star,
                                            color: starValue <= selectedRating
                                                ? Colors.yellow
                                                : Colors.grey,
                                            size:
                                                40.0, // Adjust the size of the stars as needed
                                          ),
                                        );
                                      }),
                                    ),
                                    const SizedBox(height: 10),
                                    TextField(
                                      decoration: const InputDecoration(
                                        labelText: 'Enter your comment',
                                      ),
                                      controller: commentController,
                                    ),
                                    const SizedBox(height: 10),
                                    // put button at the end of the form
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        ElevatedButton(
                                          onPressed: () {
                                            handleComment();
                                          },
                                          child: const Text('Submit'),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ))
                        : Container(),
                    // list of comments and ratings

                    ListView.separated(
                      shrinkWrap: true,
                      separatorBuilder: (BuildContext context, int index) =>
                          const Divider(),
                      itemCount: commentsAndRatings.length,
                      itemBuilder: (BuildContext context, int index) {
                        return ListTile(
                          title: Text(commentsAndRatings[index]['review']),
                          leading: const CircleAvatar(
                            // make blank avatar only without using image
                            // image: const DecorationImage(
                            backgroundImage: AssetImage(Vectors.blankProfile),
                          ),
                          // add three dot icon on the trailing with edit option and delete option if current user is the owner of the comment
                          trailing: role == 'tourist' &&
                                  commentsAndRatings[index]
                                          ['tourist_username'] ==
                                      user
                              ? PopupMenuButton(
                                  itemBuilder: (BuildContext bc) => [
                                    const PopupMenuItem(
                                      value: "edit",
                                      child: Text("Edit"),
                                    ),
                                    const PopupMenuItem(
                                      value: "delete",
                                      child: Text("Delete"),
                                    ),
                                  ],
                                  onSelected: (value) {
                                    if (value == 'edit') {
                                      // set the comment to the comment field
                                      commentController.text =
                                          commentsAndRatings[index]['review'];
                                      // set the rating to the rating field
                                      setState(() {
                                        selectedRating =
                                            commentsAndRatings[index]['rating'];
                                      });
                                      setState(() {
                                        hasComment = false;
                                      });
                                    } else if (value == 'delete') {
                                      // delete comment
                                      _reviews_and_ratings
                                          .doc(commentsAndRatings[index].id)
                                          .delete()
                                          .then((value) {
                                        // show success message
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                            content: Text('Comment deleted.'),
                                          ),
                                        );
                                        loadCommentsAndRatings();
                                        hasComment = false;
                                      }).catchError((error) {
                                        // show error message
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            content: Text(error.toString()),
                                          ),
                                        );
                                      });
                                    }
                                  },
                                )
                              : null,
                          subtitle: Column(
                            children: [
                              Row(
                                children: [
                                  for (int i = 0;
                                      i < commentsAndRatings[index]['rating'];
                                      i++)
                                    const Icon(Icons.star,
                                        color: Colors.yellow),
                                ],
                              ),
                              Row(
                                children: [
                                  const Text('by '),
                                  Text(
                                    commentsAndRatings[index]
                                        ['tourist_username'],
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Text(
                                    DateFormat('MMM d, y hh:mm a').format(
                                      commentsAndRatings[index]['created']
                                          .toDate(),
                                    ),
                                    style: const TextStyle(
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}

// ignore: must_be_immutable
class BusinessList extends StatefulWidget {
  Future<List<dynamic>> touristSpots;

  BusinessList({Key? key, required this.touristSpots}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _BusinessListState createState() => _BusinessListState();
}

class _BusinessListState extends State<BusinessList> {
  Future<bool> validateImage(String imageUrl) async {
    try {
      final response = await http.head(Uri.parse(imageUrl));

      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: widget.touristSpots,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          // return Text('Error: ${snapshot.error}');
          if (snapshot.error is DioException) {
            final res = (snapshot.error as DioException).response;
            if (res?.statusCode == 401) {
              return const Center(
                child: Text('Unauthorized'),
              );
            } else if (res?.statusCode == 403) {
              return Center(
                child: Text(res?.data['detail']),
              );
            }
          }
          return const Center(
            child: Text('Failed to load tourist spots'),
          );
        } else {
          // Extract tourist spots data
          List<dynamic> touristSpotsData = snapshot.data!;
          // convert to list of cards
          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: touristSpotsData.length,
                  itemBuilder: (context, index) {
                    // Use a default image if 'image' is null or empty
                    var image = touristSpotsData[index]['image'];
                    bool isImageValid = true;
                    // check if image is null or empty
                    if (image == null || image == '') {
                      image = Vectors.defaultImage;
                      isImageValid = false;
                    } else {
                      validateImage(image).then((value) {
                        if (!value) {
                          image = Vectors.defaultImage;
                          isImageValid = false;
                        }
                      });
                    }
                    Image imageWidget = isImageValid
                        ? Image.network(image)
                        : Image.asset(Vectors.defaultImage);
                    return Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      // add padding
                      margin: const EdgeInsets.only(
                          left: 30, right: 30, top: 30, bottom: 5),
                      child: InkWell(
                        child: Column(
                          children: [
                            const SizedBox(height: 10),
                            Container(
                              height: 200,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: imageWidget.image,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            ListTile(
                              title: Text(touristSpotsData[index]['name']),
                              // subtitle:
                              //     Text(touristSpotsData[index]['description']),
                              // trailing: Text(DateFormat('MMM d, y').format(
                              //     DateTime.parse(
                              //         snapshot.data![index]['created']))),

                              // add the created at bottom of subtitle
                              subtitle: Column(
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          touristSpotsData[index]
                                              ['description'],
                                          style: const TextStyle(
                                            fontSize: 12,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Text(
                                        DateFormat('MMM d, y').format(
                                          DateTime.parse(
                                            touristSpotsData[index]['created'],
                                          ),
                                        ),
                                        style: const TextStyle(
                                          fontSize: 10,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),

                              // add content here

                              // put star and rating here
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 30),
            ],
          );
        }
      },
    );
  }
}
