// review page boilerplate
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
final CollectionReference _reviews_and_ratings =
    _firestore.collection('reviews_and_ratings');

class Reviews extends StatefulWidget {
  @override
  _ReviewsState createState() => _ReviewsState();
}

// review page boilerplate
class _ReviewsState extends State<Reviews> {
  List<dynamic> commentsAndRatings = [];
  double averageRating = 0.0;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  loadCommentsAndRatings() async {
    // filter comments and ratings by id
    QuerySnapshot querySnapshot = await _reviews_and_ratings
        .where('tourist_spot', isEqualTo: _auth.currentUser!.uid)
        .orderBy('created', descending: true)
        .get();

    List<DocumentSnapshot> commentsAndRatings = querySnapshot.docs;
    setState(() {
      this.commentsAndRatings = commentsAndRatings;
    });
    // calculate average rating
    int totalComments = 0;
    double sum = 0;
    for (int i = 0; i < commentsAndRatings.length; i++) {
      // convert to double
      // include only not zero ratings
      if (double.parse(commentsAndRatings[i]['rating'].toString()) != 0) {
        sum += double.parse(commentsAndRatings[i]['rating'].toString());
        totalComments++;
      }
    }
    // averageRating = sum ~/ commentsAndRatings.length;
    // provide even the decimal places do not round off
    averageRating = sum / totalComments.toDouble();
    // make it 1 decimal place
    averageRating = double.parse(averageRating.toStringAsFixed(1));
    averageRating = averageRating.isNaN ? 0.0 : averageRating;
  }

  String uid = '';
  String user = '';
  String role = '';
  @override
  void initState() {
    super.initState();

    SharedPreferencesHelper.getUserInfo().then(
      (value) {
        setState(() {
          uid = value['uid'];
          user = value['username'];
          role = value['role'];
        });
        loadCommentsAndRatings();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('Comments & Ratings',
            style: TextStyle(color: Colors.black, fontSize: 20)),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              // padding on left only
              padding: const EdgeInsets.only(left: 15.0),
              child: Text(
                'Average Rating: $averageRating',
                style: const TextStyle(
                  color: Color.fromARGB(255, 75, 74, 74),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          ListView.separated(
            shrinkWrap: true,
            separatorBuilder: (BuildContext context, int index) =>
                const Divider(),
            itemCount: commentsAndRatings.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                title: Text(commentsAndRatings[index]['review']),
                leading: const CircleAvatar(
                  // make blank avatar only without using image
                  // image: const DecorationImage(
                  backgroundImage: AssetImage(Vectors.blankProfile),
                ),
                // add three dot icon on the trailing with edit option and delete option if current user is the owner of the comment
                trailing: role == 'tourist' &&
                        commentsAndRatings[index]['tourist_username'] == user
                    ? PopupMenuButton(
                        itemBuilder: (BuildContext bc) => [
                          const PopupMenuItem(
                            value: "edit",
                            child: Text("Edit"),
                          ),
                          const PopupMenuItem(
                            value: "delete",
                            child: Text("Delete"),
                          ),
                        ],
                        onSelected: (value) {},
                      )
                    : null,
                subtitle: Column(
                  children: [
                    Row(
                      children: [
                        for (int i = 0;
                            i < commentsAndRatings[index]['rating'];
                            i++)
                          const Icon(Icons.star, color: Colors.yellow),
                      ],
                    ),
                    Row(
                      children: [
                        const Text('by '),
                        Text(
                          commentsAndRatings[index]['tourist_username'],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          DateFormat('MMM d, y hh:mm a').format(
                            commentsAndRatings[index]['created'].toDate(),
                          ),
                          style: const TextStyle(
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ]),
      ),
    );
  }
}
