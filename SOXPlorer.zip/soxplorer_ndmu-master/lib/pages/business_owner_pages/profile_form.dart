import 'dart:io';

import 'package:bottom_picker/bottom_picker.dart';
import 'package:bottom_picker/resources/arrays.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:soxplorer/components/app_text_form_field.dart';
import 'package:soxplorer/shared/token.dart';
import 'package:soxplorer/values/app_constants.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:http/http.dart' as http;

class ProfileForm extends StatefulWidget {
  const ProfileForm({super.key});

  @override
  State<ProfileForm> createState() => _ProfileFormState();
}

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _collection = _firestore.collection('user_info');

class _ProfileFormState extends State<ProfileForm> {
  _ProfileFormState() {
    SharedPreferencesHelper.getUserInfo().then((value) {
      if (value.containsKey('image')) {
        validateImage(value['image']).then((isValid) {
          if (isValid) {
            setState(() {
              _image = XFile(value['image']);
            });
          }
           _isImageFromFile = false;
        });
      }
      setState(() {
        usernameController.text = value['username'] ?? '';
        emailController.text = value['email'] ?? '';
        nameController.text = value['name'] ?? '';
        birthdayController.text = value['birthday'] ?? '';
        touristSpotNameController.text = value['tourist_spot_name'] ?? '';
        selectedCategory = value['category'] ?? '';
        addressController.text = value['address'] ?? '';
      });
    });
  }

  Future<bool> validateImage(String imageUrl) async {
    try {
      final response = await http.head(Uri.parse(imageUrl));

      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  TextEditingController usernameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController birthdayController = TextEditingController();
  TextEditingController touristSpotNameController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool isObscure = true;
  final _formKey = GlobalKey<FormState>();
  Map<String, dynamic> fieldErrors = {};

  List<String> categories = [
    '-None-',
    'General Location',
    'Accommodation',
    'Restaurant and Food',
    'Activity-based',
    'Photography',
    'Others',
  ];

  String? selectedCategory = '-None-';

  final FirebaseAuth _auth = FirebaseAuth.instance;
  Future<dynamic> update() async {
    try {
      // update user info
      await _auth.currentUser!.updateEmail(emailController.text);
      // update user info using user.uid
      await _collection.doc(_auth.currentUser!.uid).update({
        'username': usernameController.text,
        'name': nameController.text,
        'birthday': birthdayController.text,
        'tourist_spot_name': touristSpotNameController.text,
        'category': selectedCategory,
        'address': addressController.text,
      });

      final DocumentSnapshot updatedDoc =
          await _collection.doc(_auth.currentUser!.uid).get();
      Map<String, dynamic> result = updatedDoc.data() as Map<String, dynamic>;

      if (_image != null) {
        // remove the old image
        if (result['image'] != null && result['image'] != '') {
          firebase_storage.Reference ref = firebase_storage
              .FirebaseStorage.instance
              .refFromURL(result['image']);
          await ref.delete();
        }

        String fileName = _image!.path.split('/').last;
        firebase_storage.Reference ref =
            firebase_storage.FirebaseStorage.instance.ref().child(fileName);
        firebase_storage.UploadTask uploadTask =
            ref.putFile(File(_image!.path));
        firebase_storage.TaskSnapshot taskSnapshot = await uploadTask;
        String imageUrl = await taskSnapshot.ref.getDownloadURL();

        await _collection.doc(updatedDoc.id).update({
          'image': imageUrl,
        });
        result['image'] = imageUrl;
      }

      result['id'] = updatedDoc.id;

      
      // update shared preferences
      SharedPreferencesHelper.setUserInfo({
        'uid': _auth.currentUser!.uid,
        'username': usernameController.text,
        'email': emailController.text,
        'name': nameController.text,
        'birthday': birthdayController.text,
        'tourist_spot_name': touristSpotNameController.text,
        'category': selectedCategory ?? '',
        'address': addressController.text,
        'image': result['image'] ?? '',
      });
      
      return result;
    } catch (error) {
      return error;
    }
  }

  void handleUpdate() {
    update().then((response) {
      if (response is FirebaseAuthException) {
        setState(() {
          fieldErrors = {
            'email': response.code == 'email-already-in-use'
                ? 'Email already in use'
                : response.code == 'invalid-email'
                    ? 'Please enter a valid email'
                    : null
          };
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Colors.green,
            content: Text('Update successfully!'),
          ),
        );
      }
      _formKey.currentState?.validate();
    });
  }

  XFile? _image;
  bool _isImageFromFile = true;
  Future<void> pickImage() async {
    _isImageFromFile = true;
    final ImagePicker picker = ImagePicker();
    XFile? pickedImage = await picker.pickImage(source: ImageSource.gallery);

    if (pickedImage != null) {
      // Get the current timestamp
      String timestamp = DateTime.now().millisecondsSinceEpoch.toString();

      // Extract the file extension from the original file path
      List<String> pathParts = pickedImage.path.split('.');
      String extension = pathParts.last;

      // Create a new file name with the timestamp and original extension
      String newFileName = 'image_$timestamp.$extension';

      // Get the directory path without the file name
      String directory = pickedImage.path.replaceAll(pickedImage.name, '');

      // Create the new file path
      String newPath = '$directory$newFileName';

      // Rename the file
      await File(pickedImage.path).copy(newPath);

      setState(() {
        _image = XFile(newPath);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          const SizedBox(height: 16),
          AppTextFormField(
            labelText: 'Username',
            controller: usernameController,
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.next,
            validator: (value) {
              return value == null || value.isEmpty
                  ? 'Please enter your username'
                  : value.length < 3
                      ? 'Username should be at least 3 characters'
                      : null;
            },
          ),
          AppTextFormField(
            readOnly: true,
            labelText: 'Email',
            controller: emailController,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            validator: (value) {
              return fieldErrors.containsKey('email')
                  ? fieldErrors['email']
                  : AppConstants.emailRegex.hasMatch(value!)
                      ? null
                      : 'Please enter a valid email';
            },
          ),
          AppTextFormField(
            labelText: 'Name',
            controller: nameController,
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.next,
            validator: (value) {
              return value == null || value.isEmpty
                  ? 'Please enter your name'
                  : null;
            },
          ),
          AppTextFormField(
            readOnly: true,
            labelText: 'Birthday',
            controller: birthdayController,
            keyboardType: TextInputType.datetime,
            textInputAction: TextInputAction.next,
            suffixIcon: Padding(
              padding: const EdgeInsets.only(right: 15),
              child: IconButton(
                onPressed: () {
                  _openDatePicker(context);
                },
                style: ButtonStyle(
                  minimumSize: MaterialStateProperty.all(
                    const Size(48, 48),
                  ),
                ),
                icon: const Icon(
                  Icons.calendar_today_outlined,
                  color: Colors.black,
                ),
              ),
            ),
            validator: (value) {
              return value == null || value.isEmpty
                  ? 'Please enter your birthday'
                  : null;
            },
          ),
          AppTextFormField(
            labelText: 'Tourist Spot Name',
            controller: touristSpotNameController,
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.next,
            validator: (value) {
              return value == null || value.isEmpty
                  ? 'Please enter your tourist spot name'
                  : null;
            },
          ),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
              labelText: 'Category',
              floatingLabelBehavior: FloatingLabelBehavior.always,
            ),
            value: selectedCategory,
            validator: (value) {
              return value!.isEmpty
                  ? 'Category is required'
                  : value == '-None-'
                      ? 'Category is required'
                      : null;
            },
            icon: const Icon(Icons.arrow_drop_down),
            iconSize: 24,
            elevation: 16,
            style: const TextStyle(color: Colors.black),
            onChanged: (String? newValue) {
              setState(() {
                selectedCategory = newValue;
              });
            },
            items: categories.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
              );
            }).toList(),
          ),
          const SizedBox(height: 10),
          AppTextFormField(
            labelText: 'Address',
            controller: addressController,
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.next,
            validator: (value) {
              return value == null || value.isEmpty
                  ? 'Please enter your address'
                  : null;
            },
          ),
          // button
          const SizedBox(height: 16),
          _image == null
              ? const Text('No image selected.')
              : _isImageFromFile
                  ? Image.file(
                      File(_image!.path),
                      height: 200.0,
                      width: 200.0,
                      fit: BoxFit.cover,
                    )
                  : Image.network(
                      _image!.path, // Assuming _image.path contains the URL
                      height: 200.0,
                      width: 200.0,
                      fit: BoxFit.cover,
                    ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () async {
                    pickImage();
                  },
                  // change background color
                  style: Theme.of(context).outlinedButtonTheme.style,
                  icon: const Icon(
                    Icons.image,
                    color: Color.fromARGB(255, 32, 248, 4),
                  ),
                  label: const Text(
                    'Upload Image',
                    style: TextStyle(color: Color.fromARGB(255, 99, 33, 33)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    if (!_formKey.currentState!.validate()) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Please fill in all the required fields'),
                        backgroundColor: Colors.red,
                      ));
                      return;
                    }
                    handleUpdate();
                  },
                  // change background color
                  style: Theme.of(context).outlinedButtonTheme.style?.copyWith(
                        backgroundColor: MaterialStateProperty.all(
                          const Color.fromARGB(255, 255, 203, 67),
                        ),
                      ),
                  icon: const Icon(
                    Icons.update,
                    color: Colors.white,
                  ),
                  label: const Text(
                    'Update',
                    style: TextStyle(color: Color.fromARGB(255, 99, 33, 33)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  void _openDatePicker(BuildContext context) {
    BottomPicker.date(
      title: 'Set your Birthday',
      dateOrder: DatePickerDateOrder.dmy,
      initialDateTime: DateTime(1996, 10, 22),
      maxDateTime: DateTime(2024),
      minDateTime: DateTime(1980),
      pickerTextStyle: const TextStyle(
        color: Colors.blue,
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      titleStyle: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 15,
        color: Colors.blue,
      ),
      onSubmit: (date) {
        setState(() {
          birthdayController.text = date.toString().split(' ')[0];
        });
      },
      bottomPickerTheme: BottomPickerTheme.plumPlate,
    ).show(context);
  }
}
