import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:soxplorer/components/app_text_form_field.dart';
import 'package:soxplorer/shared/token.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:http/http.dart' as http;

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _tourist_sport_collection =
    _firestore.collection('tourist_spots');

class TouristSpotForm extends StatefulWidget {
  final Map<String, dynamic>? touristSpot;
  const TouristSpotForm({super.key, this.touristSpot});

  @override
  // ignore: library_private_types_in_public_api
  _TouristSpotFormState createState() => _TouristSpotFormState();
}

class _TouristSpotFormState extends State<TouristSpotForm> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String owner = '';

  String getOwner() {
    SharedPreferencesHelper.getUserInfo().then((value) {
      setState(() {
        owner = value['uid'];
      });
    });
    return owner;
  }

  Future<bool> validateImage(String imageUrl) async {
    try {
      final response = await http.head(Uri.parse(imageUrl));

      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  bool _isImageFromFile = true;
  @override
  void initState() {
    super.initState();
    if (widget.touristSpot != null) {
      nameController.text = widget.touristSpot!['name'];
      descriptionController.text = widget.touristSpot!['description'];
      if (widget.touristSpot!.containsKey('image')) {
        validateImage(widget.touristSpot!['image'])
            .then((value) =>{
              if(value){
                setState(() {
                  _image = XFile(widget.touristSpot!['image']);
                })
              }
            });
      }
      _isImageFromFile = false;
    }
    owner = getOwner();
  }

  XFile? _image;

  Future<void> pickImage() async {
    _isImageFromFile = true;
    final ImagePicker picker = ImagePicker();
    XFile? pickedImage = await picker.pickImage(source: ImageSource.gallery);

    if (pickedImage != null) {
      // Get the current timestamp
      String timestamp = DateTime.now().millisecondsSinceEpoch.toString();

      // Extract the file extension from the original file path
      List<String> pathParts = pickedImage.path.split('.');
      String extension = pathParts.last;

      // Create a new file name with the timestamp and original extension
      String newFileName = 'image_$timestamp.$extension';

      // Get the directory path without the file name
      String directory = pickedImage.path.replaceAll(pickedImage.name, '');

      // Create the new file path
      String newPath = '$directory$newFileName';

      // Rename the file
      await File(pickedImage.path).copy(newPath);

      setState(() {
        _image = XFile(newPath);
      });
    }
  }

  Future<Map<String, dynamic>> handleCreateTouristSpot(data) async {
    try {
      DocumentReference docRef = await _tourist_sport_collection.add({
        'name': data['name'],
        'description': data['description'],
        'owner': owner,
        'created': DateTime.now().toString(),
      });
      DocumentSnapshot docSnap = await docRef.get();
      Map<String, dynamic> result = docSnap.data() as Map<String, dynamic>;

      if (_image != null) {
        String fileName = _image!.path.split('/').last;
        firebase_storage.Reference ref =
            firebase_storage.FirebaseStorage.instance.ref().child(fileName);
        firebase_storage.UploadTask uploadTask =
            ref.putFile(File(_image!.path));
        firebase_storage.TaskSnapshot taskSnapshot = await uploadTask;
        String imageUrl = await taskSnapshot.ref.getDownloadURL();

        await _tourist_sport_collection.doc(docRef.id).update({
          'image': imageUrl,
        });

        result['id'] = docRef.id; // Add the document ID to the result
        result['image'] = imageUrl;
      } else {
        result['id'] = docRef.id; // Add the document ID to the result
      }
      return result;
    } catch (error) {
      if (error is FirebaseException) {
        return {'error': 'Something went wrong with Firebase'};
      } else {
        return {'error': 'Something went wrong $error'};
      }
    }
  }

  Future<Map<String, dynamic>> handleUpdateTouristSpot(data) async {
    try {
      await _tourist_sport_collection.doc(data['id']).update({
        'name': data['name'],
        'description': data['description'],
      });

      // Fetch the updated data from Firestore
      final DocumentSnapshot updatedDoc =
          await _tourist_sport_collection.doc(data['id']).get();
      Map<String, dynamic> result = updatedDoc.data() as Map<String, dynamic>;

      // if there is an image
      if (_image != null) {
        String fileName = _image!.path.split('/').last;
        firebase_storage.Reference ref =
            firebase_storage.FirebaseStorage.instance.ref().child(fileName);
        firebase_storage.UploadTask uploadTask =
            ref.putFile(File(_image!.path));
        firebase_storage.TaskSnapshot taskSnapshot = await uploadTask;
        String imageUrl = await taskSnapshot.ref.getDownloadURL();

        await _tourist_sport_collection.doc(data['id']).update({
          'image': imageUrl,
        });
        result['image'] = imageUrl;
      }

      result['id'] = data['id'];
      return result;
    } catch (error) {
      return {'error': 'Something went wrong'};
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Post',
            style: TextStyle(color: Colors.white, fontSize: 15)),
        backgroundColor: const Color.fromARGB(255, 31, 81, 255),
        // change the color of back button
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack(children: <Widget>[
        SingleChildScrollView(
          // add padding
          padding: const EdgeInsets.all(20.0),
          physics: const BouncingScrollPhysics(),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppTextFormField(
                  labelText: 'Name',
                  controller: nameController,
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.next,
                  validator: (value) {
                    return value!.isEmpty ? 'Name is required' : null;
                  },
                ),
                AppTextFormField(
                  labelText: 'Description',
                  controller: descriptionController,
                  keyboardType: TextInputType.multiline,
                  textInputAction: TextInputAction.newline,
                  maxLines: 3,
                  floatingLabelBehavior: FloatingLabelBehavior.always,
                  validator: (value) {
                    return value!.isEmpty ? 'Description is required' : null;
                  },
                ),
                const SizedBox(height: 10),
                // image picker
                // preview image
                _image == null
                    ? const Text('No image selected.')
                    : _isImageFromFile
                        ? Image.file(
                            File(_image!.path),
                            height: 200.0,
                            width: 200.0,
                            fit: BoxFit.cover,
                          )
                        : Image.network(
                            _image!
                                .path, // Assuming _image.path contains the URL
                            height: 200.0,
                            width: 200.0,
                            fit: BoxFit.cover,
                          ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () async {
                          pickImage();
                        },
                        // change background color
                        style: Theme.of(context).outlinedButtonTheme.style,
                        icon: const Icon(
                          Icons.image,
                          color: Color.fromARGB(255, 32, 248, 4),
                        ),
                        label: const Text(
                          'Upload Image',
                          style:
                              TextStyle(color: Color.fromARGB(255, 99, 33, 33)),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          if (!_formKey.currentState!.validate()) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                    'Please fill up all the required fields!'),
                                backgroundColor: Colors.red,
                              ),
                            );
                            return;
                          }
                          // make image required
                          if (_image == null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Please upload an image!'),
                                backgroundColor: Colors.red,
                              ),
                            );
                            return;
                          }

                          var newTouristSpot = {
                            'name': nameController.text,
                            'description': descriptionController.text,
                          };
                          if (widget.touristSpot != null) {
                            newTouristSpot['id'] = widget.touristSpot!['id'];
                            handleUpdateTouristSpot(newTouristSpot)
                                .then((value) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Tourist Spot updated!'),
                                  backgroundColor: Colors.green,
                                ),
                              );
                              // back to previous page
                              Navigator.of(context).pop(value);
                            });
                          } else {
                            if (!_formKey.currentState!.validate()) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                      'Please fill up all the required fields!'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                              return;
                            }
                            handleCreateTouristSpot(newTouristSpot)
                                .then((value) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Tourist Spot created!'),
                                  backgroundColor: Colors.green,
                                ),
                              );
                              // back to previous page
                              Navigator.of(context).pop(value);
                            });
                          }
                        },
                        // change background color
                        style: Theme.of(context).outlinedButtonTheme.style,
                        icon: const Icon(
                          Icons.save,
                          color: Color.fromARGB(255, 248, 4, 4),
                        ),
                        label: const Text(
                          'Save',
                          style:
                              TextStyle(color: Color.fromARGB(255, 99, 33, 33)),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }
}
