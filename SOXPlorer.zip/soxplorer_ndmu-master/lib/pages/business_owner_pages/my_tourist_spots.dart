import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:intl/intl.dart';
import 'package:soxplorer/pages/business_owner_pages/reviews_ratings.dart';
import 'package:soxplorer/pages/business_owner_pages/tourist_spot_form.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _tourist_sport_collection =
    _firestore.collection('tourist_spots');

// ignore: must_be_immutable
class TouristSpots extends StatefulWidget {
  const TouristSpots({super.key});

  @override
  State<TouristSpots> createState() => _TouristSpotsState();
}

class _TouristSpotsState extends State<TouristSpots> {
  Future<List<dynamic>> touristSpots = Future<List<dynamic>>.value([]);

  Future<List<dynamic>> getTouristSpots() async {
    await Future.delayed(const Duration(seconds: 1));
    // use the collection reference to get all documents
    // filter the documents by the owner
    QuerySnapshot querySnapshot =
        await _tourist_sport_collection.where('owner', isEqualTo: owner).get();
    List<dynamic> response = [];
    for (var doc in querySnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      data['id'] = doc.id; // Add the document ID to the data
      response.add(data);
    }
    print(response);
    return response;
  }

  @override
  void initState() {
    super.initState();
    owner = getOwner();
    touristSpots = getTouristSpots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: BusinessList(touristSpots: touristSpots),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const TouristSpotForm(),
            ),
          ).then((value) {
            var id = value['id'];
            if (id != null && id is String) {
              value['id'] = id.toString();
              value['image'] =
                  value['image'] ?? 'https://via.placeholder.com/150';
              setState(() {
                touristSpots = touristSpots.then((touristSpotsList) {
                  return [value, ...touristSpotsList];
                });
              });
            }
          });
        },
        // change color
        backgroundColor: const Color.fromARGB(255, 31, 81, 255),
        foregroundColor: Colors.white,
        child: const Icon(Icons.add),
      ),
    );
  }

  String owner = '';

  String getOwner() {
    SharedPreferencesHelper.getUserInfo().then((value) {
      setState(() {
        owner = value['uid'];
      });
    });
    return owner;
  }
}

// ignore: must_be_immutable
class BusinessList extends StatefulWidget {
  Future<List<dynamic>> touristSpots;

  BusinessList({Key? key, required this.touristSpots}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _BusinessListState createState() => _BusinessListState();
}

class _BusinessListState extends State<BusinessList> {
  var dio = Dio();

  TextEditingController nameController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: widget.touristSpots,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          // return Text('Error: ${snapshot.error}');
          if (snapshot.error is DioException) {
            final res = (snapshot.error as DioException).response;
            if (res?.statusCode == 401) {
              return const Center(
                child: Text('Unauthorized'),
              );
            } else if (res?.statusCode == 403) {
              return Center(
                child: Text(res?.data['detail']),
              );
            }
          }
          return const Center(
            child: Text('Failed to load tourist spots'),
          );
        } else {
          return ListView.builder(
            itemCount: snapshot.data == null ? 0 : snapshot.data!.length,
            itemBuilder: (context, index) {
              var image = snapshot.data![index]['image'];
              // check if image is null or empty
              bool isUrl = true;
              if (image == null || image == '') {
                isUrl = false;
                image = Vectors.defaultImage;
              }
              return Card(
                child: ListTile(
                  // put image here
                  // leading: Image.network(
                  //   image,
                  //   width: 50,
                  //   height: 50,
                  // ),
                  // make it avatar
                  leading: CircleAvatar(
                    backgroundImage:
                        isUrl ? NetworkImage(image) : Image.asset(image).image,
                    maxRadius: 25,
                  ),
                  title: Text(snapshot.data![index]['name']),
                  subtitle: Text(
                    DateFormat('MMM. d, y').format(
                        DateTime.parse(snapshot.data![index]['created'])),
                    style: const TextStyle(
                      color: Colors.grey,
                      fontSize: 12.0,
                    ),
                  ),
                  // add two action buttons
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TouristSpotForm(
                                touristSpot: snapshot.data![index],
                              ),
                            ),
                          ).then((value) {
                            List<dynamic> touristSpots = snapshot.data!;
                            // find the index of the touristSpots
                            int index = touristSpots.indexWhere(
                                (element) => element['id'] == value['id']);
                            if (value['id'] != null) {
                              touristSpots[index] = {
                                'id': value['id'],
                                'name': value['name'],
                                'description': value['description'],
                                'image': value['image'] ??
                                    'https://via.placeholder.com/150',
                              };
                              print('image: ${value['image']}');
                              setState(() {
                                touristSpots = touristSpots;
                              });
                            }
                          });
                        },
                        icon: const Icon(
                          Icons.edit,
                          color: Color.fromARGB(255, 4, 198, 4),
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          _deleteDialogBuilder(
                              context, snapshot.data![index], snapshot);
                        },
                        icon: const Icon(
                          Icons.delete,
                          color: Color.fromARGB(255, 248, 4, 4),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }
      },
    );
  }

  Future<bool> handleDeleteTouristSpot(data) {
    try {
      _tourist_sport_collection.doc(data['id']).delete();
      return Future.value(true);
    } catch (error) {
      return Future.value(false);
    }
  }

  Future<void> _deleteDialogBuilder(
      BuildContext context, dynamic data, AsyncSnapshot<dynamic> snapshot) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            'Delete Business',
            style: TextStyle(
              color: Color.fromARGB(255, 99, 33, 33),
            ),
          ),
          content: Stack(children: <Widget>[
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Form(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Are you sure you want to delete ${data['name']}?',
                      style: const TextStyle(
                        color: Color.fromARGB(255, 99, 33, 33),
                      ),
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              // find the touristSpots based on the id
                              List<dynamic> touristSpots = snapshot.data!;
                              // find the index of the toursitSpot

                              handleDeleteTouristSpot(data).then((value) {
                                if (value) {
                                  print(value);
                                  // remove the toursitSpot
                                  int index = touristSpots.indexWhere(
                                      (element) => element['id'] == data['id']);
                                  touristSpots.removeAt(index);
                                  // update the touristSpots
                                  setState(() {
                                    touristSpots = touristSpots;
                                  });

                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Tourist Spot deleted!'),
                                      backgroundColor: Colors.green,
                                    ),
                                  );
                                  Navigator.of(context).pop();
                                }
                              });
                            },
                            // change background color
                            style: Theme.of(context).outlinedButtonTheme.style,
                            icon: const Icon(
                              Icons.delete,
                              color: Color.fromARGB(255, 248, 4, 4),
                            ),
                            label: const Text(
                              'Delete',
                              style: TextStyle(
                                  color: Color.fromARGB(255, 99, 33, 33)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ]),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text(
                'Cancel',
                style: TextStyle(
                  color: Color.fromARGB(255, 25, 23, 23),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ignore: non_constant_identifier_names
  void _show_comments_and_ratings(BuildContext context, param1) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CommentsAndRatingsPage(data: param1),
      ),
    );
  }
}
