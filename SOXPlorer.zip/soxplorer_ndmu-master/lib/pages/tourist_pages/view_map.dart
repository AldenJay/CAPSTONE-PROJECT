import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class GoogleMapsIframe extends StatelessWidget {
  final dynamic location;
  final WebViewController controller = WebViewController();
  GoogleMapsIframe({super.key, required this.location});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 255, 118, 68),
        title: Text(location,
            style: const TextStyle(color: Colors.white, fontSize: 15)),
      ),
      body: WebViewWidget(
          controller: controller
            ..setJavaScriptMode(JavaScriptMode.unrestricted)
            ..setNavigationDelegate(
              NavigationDelegate(
                onProgress: (int progress) {},
                onPageStarted: (String url) {},
                onPageFinished: (String url) {},
                onWebResourceError: (WebResourceError error) {},
                onNavigationRequest: (NavigationRequest request) {
                  return NavigationDecision.navigate;
                },
              ),
            )
            ..loadRequest(Uri.dataFromString('''<html>
          <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              body {
                margin: 0;
                padding: 0;
              }
            </style>
          </head>
          <body>
            <iframe style="width:100%;height:100%;" src="http://maps.google.com/maps?q=$location&output=embed" 
              title="$location" frameborder="0"></iframe>
          </body>
        </html>''', mimeType: 'text/html'))),
    );
  }
}
