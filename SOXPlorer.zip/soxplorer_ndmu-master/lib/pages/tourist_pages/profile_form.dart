import 'package:bottom_picker/bottom_picker.dart';
import 'package:bottom_picker/resources/arrays.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:soxplorer/components/app_text_form_field.dart';
import 'package:soxplorer/shared/token.dart';
import 'package:soxplorer/values/app_constants.dart';

class ProfileForm extends StatefulWidget {
  const ProfileForm({super.key});

  @override
  State<ProfileForm> createState() => _ProfileFormState();
}

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _collection = _firestore.collection('user_info');

class _ProfileFormState extends State<ProfileForm> {
  _ProfileFormState() {
    SharedPreferencesHelper.getUserInfo().then((value) {
      setState(() {
        usernameController.text = value['username'] ?? '';
        emailController.text = value['email'] ?? '';
        birthdayController.text = value['birthday'] ?? '';
      });
    });
  }

  TextEditingController usernameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController birthdayController = TextEditingController();
  bool isObscure = true;
  final _formKey = GlobalKey<FormState>();
  Map<String, dynamic> fieldErrors = {};

  final FirebaseAuth _auth = FirebaseAuth.instance;
  Future<dynamic> update() async {
    try {
      // update user info
      await _auth.currentUser!.updateEmail(emailController.text);
      // update user info using user.uid
      await _collection.doc(_auth.currentUser!.uid).update({
        'username': usernameController.text,
        'birthday': birthdayController.text,
      });

      // update shared preferences
      SharedPreferencesHelper.setUserInfo({
        'username': usernameController.text,
        'email': emailController.text,
        'birthday': birthdayController.text,
      });
      final DocumentSnapshot updatedDoc =
          await _collection.doc(_auth.currentUser!.uid).get();
      Map<String, dynamic> result = updatedDoc.data() as Map<String, dynamic>;
      result['id'] = updatedDoc.id;
      return result;
    } catch (error) {
      return error;
    }
  }

  void handleUpdate() {
    update().then((response) {
      if (response is FirebaseAuthException) {
        setState(() {
          fieldErrors = {
            'email': response.code == 'email-already-in-use'
                ? 'Email already in use'
                : response.code == 'invalid-email'
                    ? 'Please enter a valid email'
                    : response.code == 'operation-not-allowed'
                        ? response.message
                        : 'Something went wrong',
          };
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Colors.green,
            content: Text('Update successfully!'),
          ),
        );
      }

      _formKey.currentState?.validate();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          const SizedBox(height: 16),
          AppTextFormField(
            labelText: 'Username',
            controller: usernameController,
            keyboardType: TextInputType.text,
            textInputAction: TextInputAction.next,
            validator: (value) {
              return value == null || value.isEmpty
                  ? 'Please enter your username'
                  : value.length < 3
                      ? 'Username should be at least 3 characters'
                      : null;
            },
          ),
          AppTextFormField(
            readOnly: true,
            labelText: 'Email',
            controller: emailController,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            validator: (value) {
              return fieldErrors.containsKey('email')
                  ? fieldErrors['email']
                  : AppConstants.emailRegex.hasMatch(value!)
                      ? null
                      : 'Please enter a valid email';
            },
          ),
          AppTextFormField(
            readOnly: true,
            labelText: 'Birthday',
            controller: birthdayController,
            keyboardType: TextInputType.datetime,
            textInputAction: TextInputAction.next,
            suffixIcon: Padding(
              padding: const EdgeInsets.only(right: 15),
              child: IconButton(
                onPressed: () {
                  _openDatePicker(context);
                },
                style: ButtonStyle(
                  minimumSize: MaterialStateProperty.all(
                    const Size(48, 48),
                  ),
                ),
                icon: const Icon(
                  Icons.calendar_today_outlined,
                  color: Colors.black,
                ),
              ),
            ),
            validator: (value) {
              return value == null || value.isEmpty
                  ? 'Please enter your birthday'
                  : null;
            },
          ),
          // button
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    if (!_formKey.currentState!.validate()) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Please fill in all the required fields'),
                        backgroundColor: Colors.red,
                      ));
                      return;
                    }
                    handleUpdate();
                  },
                  // change background color
                  style: Theme.of(context).outlinedButtonTheme.style?.copyWith(
                        backgroundColor: MaterialStateProperty.all(
                          const Color.fromARGB(255, 255, 203, 67),
                        ),
                      ),
                  icon: const Icon(
                    Icons.update,
                    color: Colors.white,
                  ),
                  label: const Text(
                    'Update',
                    style: TextStyle(color: Color.fromARGB(255, 99, 33, 33)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  void _openDatePicker(BuildContext context) {
    BottomPicker.date(
      title: 'Set your Birthday',
      dateOrder: DatePickerDateOrder.dmy,
      initialDateTime: DateTime(1996, 10, 22),
      maxDateTime: DateTime(2024),
      minDateTime: DateTime(1980),
      pickerTextStyle: const TextStyle(
        color: Colors.blue,
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      titleStyle: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 15,
        color: Colors.blue,
      ),
      onSubmit: (date) {
        setState(() {
          birthdayController.text = date.toString().split(' ')[0];
        });
      },
      bottomPickerTheme: BottomPickerTheme.plumPlate,
    ).show(context);
  }
}
