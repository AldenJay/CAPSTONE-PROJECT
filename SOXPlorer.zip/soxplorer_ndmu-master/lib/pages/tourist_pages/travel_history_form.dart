import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:soxplorer/components/app_text_form_field.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';
import 'package:http/http.dart' as http;

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _travel_history =
    _firestore.collection('travel_history');

class TravelHistoryForm extends StatefulWidget {
  final Map<String, dynamic>? history;
  const TravelHistoryForm({super.key, this.history});

  @override
  // ignore: library_private_types_in_public_api
  _TravelHistoryFormState createState() => _TravelHistoryFormState();
}

class _TravelHistoryFormState extends State<TravelHistoryForm> {
  final TextEditingController descriptionController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String user = '';

  String getUser() {
    SharedPreferencesHelper.getUserInfo().then(
      (value) => setState(() {
        user = value['username'];
      }),
    );
    return user;
  }

  validateCategory(category) {
    if (category == null) {
      return '';
    }
    return category;
  }

  Future<bool> validateImage(dynamic imageUrl) async {
    try {
      final response = await http.head(Uri.parse(imageUrl));

      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  bool _isImageFromFile = true;
  @override
  void initState() {
    super.initState();
    if (widget.history != null) {
      if (widget.history!.containsKey("description")) {
        descriptionController.text = widget.history!['description'];
      }
      if (widget.history!.containsKey('image')) {
        validateImage(widget.history!['image']).then((value) => {
              if (value)
                {
                  setState(() {
                    _image = XFile(widget.history!['image']);
                  })
                }
            });
      }
      _isImageFromFile = false;
    }
    user = getUser();
  }

  XFile? _image;

  Future<void> pickImage() async {
    _isImageFromFile = true;
    final ImagePicker picker = ImagePicker();
    XFile? pickedImage = await picker.pickImage(source: ImageSource.gallery);

    if (pickedImage != null) {
      // Get the current timestamp
      String timestamp = DateTime.now().millisecondsSinceEpoch.toString();

      // Extract the file extension from the original file path
      List<String> pathParts = pickedImage.path.split('.');
      String extension = pathParts.last;

      // Create a new file name with the timestamp and original extension
      String newFileName = 'image_$timestamp.$extension';

      // Get the directory path without the file name
      String directory = pickedImage.path.replaceAll(pickedImage.name, '');

      // Create the new file path
      String newPath = '$directory$newFileName';

      // Rename the file
      await File(pickedImage.path).copy(newPath);

      setState(() {
        _image = XFile(newPath);
      });
    }
  }

  Future<Map<String, dynamic>> handleUpdateTouristSpot(data) async {
    try {
      await _travel_history.doc(data['id']).update({
        'description': data['description'],
      });

      // Fetch the updated data from Firestore
      final DocumentSnapshot updatedDoc =
          await _travel_history.doc(data['id']).get();
      Map<String, dynamic> result = updatedDoc.data() as Map<String, dynamic>;

      result['id'] = data['id'];
      return result;
    } catch (error) {
      return {'error': 'Something went wrong'};
    }
  }

  List<String> categories = [
    '-None-',
    'General Location',
    'Accommodation',
    'Restaurant and Food',
    'Activity-based',
    'Photography',
    'Others',
  ];

  String? selectedCategory = '-None-';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Journey Details',
            style: TextStyle(color: Colors.white, fontSize: 15)),
        backgroundColor: const Color.fromARGB(255, 31, 81, 255),
        // change back button color
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack(children: <Widget>[
        SingleChildScrollView(
          // add padding
          padding: const EdgeInsets.all(20.0),
          physics: const BouncingScrollPhysics(),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _image == null
                    ? Image.asset(
                        Vectors.defaultImage,
                        height: 200.0,
                        width: 200.0,
                        fit: BoxFit.cover,
                      )
                    : _isImageFromFile
                        ? Image.file(
                            File(_image!.path),
                            height: 200.0,
                            width: 200.0,
                            fit: BoxFit.cover,
                          )
                        : Image.network(
                            _image!
                                .path, // Assuming _image.path contains the URL
                            height: 200.0,
                            width: 200.0,
                            fit: BoxFit.cover,
                          ),
                const SizedBox(height: 10),

                Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 15.0),
                    child: Text(
                      widget.history!['tourist_spot_name'].toString().toUpperCase(),
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    // padding on left only
                    padding: const EdgeInsets.only(left: 15.0),
                    child: Text(
                      validateCategory(widget.history!['category']),
                      style: const TextStyle(
                        color: Color.fromARGB(255, 75, 74, 74),
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    // padding on left only
                    padding: const EdgeInsets.only(left: 15.0),
                    child: Text(
                      "Address: ${widget.history!['address']}",
                      style: const TextStyle(
                        color: Color.fromARGB(255, 75, 74, 74),
                        fontSize: 12, // Decrease font size
                        fontWeight: FontWeight.w400, // Make font weight thinner
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                AppTextFormField(
                  labelText: 'Description',
                  controller: descriptionController,
                  keyboardType: TextInputType.multiline,
                  textInputAction: TextInputAction.newline,
                  maxLines: 3,
                  floatingLabelBehavior: FloatingLabelBehavior.always,
                ),
                // preview image
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          if (!_formKey.currentState!.validate()) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                    'Please fill up all the required fields!'),
                                backgroundColor: Colors.red,
                              ),
                            );
                            return;
                          }
                          var newTravelHistory = {
                            'description': descriptionController.text,
                          };
                          if (widget.history != null) {
                            newTravelHistory['id'] = widget.history!['id'];
                            handleUpdateTouristSpot(newTravelHistory)
                                .then((value) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Travel History updated!'),
                                  backgroundColor: Colors.green,
                                ),
                              );
                              // back to previous page
                              Navigator.of(context).pop(value);
                            });
                          }
                        },
                        // change background color
                        style: Theme.of(context).outlinedButtonTheme.style,
                        icon: const Icon(
                          Icons.save,
                          color: Color.fromARGB(255, 248, 4, 4),
                        ),
                        label: const Text(
                          'Save',
                          style:
                              TextStyle(color: Color.fromARGB(255, 99, 33, 33)),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ]),
    );
  }
}
