import 'package:avatars/avatars.dart';
import 'package:flutter/material.dart';
import 'package:soxplorer/pages/tourist_pages/profile_form.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';

// ignore: must_be_immutable
class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const Expanded(flex: 2, child: _TopPortion()),
          Expanded(
            flex: 3,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  StreamBuilder<Map<String, dynamic>>(
                    stream: SharedPreferencesHelper.userInfoStream,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const CircularProgressIndicator();
                      } else if (snapshot.hasError) {
                        return Text('Error: ${snapshot.error}');
                      } else if (snapshot.hasData) {
                        String username = snapshot.data!['username'];
                        return Text(
                          username.toUpperCase(),
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge
                              ?.copyWith(fontWeight: FontWeight.bold),
                        );
                      } else {
                        return const Text('No data available');
                      }
                    },
                  ),
                  const SizedBox(height: 16),
                  // add scrollable form
                  const Expanded(
                    child: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: ProfileForm(),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TopPortion extends StatefulWidget {
  const _TopPortion({Key? key}) : super(key: key);

  @override
  State<_TopPortion> createState() => _TopPortionState();
}

class _TopPortionState extends State<_TopPortion> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(
          margin: const EdgeInsets.only(bottom: 50),
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: Image.asset(Vectors.bgMarbel).image,
                  fit: BoxFit.cover),
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(50),
                bottomRight: Radius.circular(50),
              )),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: SizedBox(
            width: 150,
            height: 150,
            child: StreamBuilder<Map<String, dynamic>>(
              stream: SharedPreferencesHelper.userInfoStream,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const CircularProgressIndicator();
                } else if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                } else if (snapshot.hasData) {
                  return const CircleAvatar(
                    // make blank avatar only without using image
                    // image: const DecorationImage(
                    backgroundImage: AssetImage(Vectors.blankProfile),
                  );
                } else {
                  return const Text('No data available');
                }
              },
            ),
          ),
        )
      ],
    );
  }
}

// ignore: must_be_immutable
