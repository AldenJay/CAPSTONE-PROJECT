import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:soxplorer/pages/business_owner_pages/reviews_ratings.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';
import 'package:http/http.dart' as http;

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _tourist_sport_collection =
    _firestore.collection('user_info');

final CollectionReference _reviews_and_ratings_collection =
    _firestore.collection('reviews_and_ratings');

// ignore: must_be_immutable
class TouristSpots extends StatefulWidget {
  const TouristSpots({super.key});

  @override
  State<TouristSpots> createState() => _TouristSpotsState();
}

class _TouristSpotsState extends State<TouristSpots> {
  Future<List<dynamic>> touristSpots = Future<List<dynamic>>.value([]);
  TextEditingController searchController = TextEditingController();

  Future<List<dynamic>> getTouristSpots() async {
    await Future.delayed(const Duration(seconds: 1));
    // use the collection reference to get all documents
    // filter the documents by the owner
    QuerySnapshot querySnapshot = await _tourist_sport_collection.where('role', isEqualTo: 'business_owner').get();
    List<dynamic> response = [];
    for (var doc in querySnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      data['id'] = doc.id; // Add the document ID to the data

      // calculate the average rating
      QuerySnapshot ratingSnapshot = await _reviews_and_ratings_collection
          .where('tourist_spot', isEqualTo: doc.id)
          .get();

      double ratingSum = 0;
      for (var ratingDoc in ratingSnapshot.docs) {
        Map<String, dynamic> ratingData =
            ratingDoc.data() as Map<String, dynamic>;
        ratingSum += ratingData['rating'];
      }
      double averageRating = (ratingSum / ratingSnapshot.size).toDouble();
      averageRating = averageRating.isNaN ? 0.0 : averageRating;
      data['average_rating'] = double.parse(averageRating.toStringAsFixed(1));
      response.add(data);
    }

    // sort by rating
    response.sort((a, b) {
      double ratingA = a['average_rating'];
      double ratingB = b['average_rating'];
      return ratingB.compareTo(ratingA);
    });
    return response;
  }

  // get tourist spots with search
  Future<List<dynamic>> getTouristSpotsWithSearch({
    String? name,
    String? category,
    String? sortBy,
  }) async {
    await Future.delayed(const Duration(seconds: 1));

    // Use the collection reference to get all documents
    QuerySnapshot querySnapshot = await _tourist_sport_collection.where('role', isEqualTo: 'business_owner').get();
    List<dynamic> response = [];

    // Filter and sort the documents based on the provided parameters
    for (var doc in querySnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      data['id'] = doc.id; // Add the document ID to the data

      // calculate the average rating
      QuerySnapshot ratingSnapshot = await _reviews_and_ratings_collection
          .where('tourist_spot', isEqualTo: doc.id)
          .get();

      double ratingSum = 0;
      for (var ratingDoc in ratingSnapshot.docs) {
        Map<String, dynamic> ratingData =
            ratingDoc.data() as Map<String, dynamic>;
        ratingSum += ratingData['rating'];
      }
      double averageRating = (ratingSum / ratingSnapshot.size).toDouble();
      data['average_rating'] = double.parse(averageRating.toStringAsFixed(1));

      // Check if the name contains the search string (if provided)
      bool nameMatches = name == null ||
          data['name'].toString().toLowerCase().contains(name.toLowerCase());

      // Check if the category matches the search category (if provided)
      bool categoryMatches = category == null ||
          category == 'All' ||
          data['category']
              .toString()
              .toLowerCase()
              .contains(category.toLowerCase());

      // If both conditions are true, add the data to the response
      if (nameMatches && categoryMatches) {
        response.add(data);
      }
    }

    // Sort the response based on the provided sortBy parameter
    if (sortBy != null) {
      if (sortBy == 'By Name') {
        for (var touristSpot in response) {
          QuerySnapshot ratingSnapshot = await _reviews_and_ratings_collection
              .where('tourist_spot', isEqualTo: touristSpot['id'])
              .get();

          double ratingSum = 0;
          for (var ratingDoc in ratingSnapshot.docs) {
            Map<String, dynamic> ratingData =
                ratingDoc.data() as Map<String, dynamic>;
            ratingSum += ratingData['rating'];
          }
          double averageRating =
              (ratingSum / ratingSnapshot.size).toDouble();
          averageRating = averageRating.isNaN ? 0.0 : averageRating;
          touristSpot['average_rating'] =
              double.parse(averageRating.toStringAsFixed(1));
        }
        response.sort((a, b) => a['name'].compareTo(b['name']));
      } else if (sortBy == 'By Rating') {
        for (var touristSpot in response) {
          QuerySnapshot ratingSnapshot = await _reviews_and_ratings_collection
              .where('tourist_spot', isEqualTo: touristSpot['id'])
              .get();

          double ratingSum = 0;
          for (var ratingDoc in ratingSnapshot.docs) {
            Map<String, dynamic> ratingData =
                ratingDoc.data() as Map<String, dynamic>;
            ratingSum += ratingData['rating'];
          }
          double averageRating =
              (ratingSum / ratingSnapshot.size).toDouble();
          averageRating = averageRating.isNaN ? 0.0 : averageRating;
          touristSpot['average_rating'] =
              double.parse(averageRating.toStringAsFixed(1));
        }

        // Sort the response based on ratings
        response.sort((a, b) {
          double ratingA = a['average_rating'];
          double ratingB = b['average_rating'];
          return ratingB.compareTo(ratingA);
        });
      } 
    }

    return response;
  }

  @override
  void initState() {
    super.initState();
    owner = getOwner();
    touristSpots = getTouristSpots();
  }

  List<String> categories = [
    'All',
    'General Location',
    'Accommodation',
    'Restaurant and Food',
    'Activity-based',
    'Photography',
    'Others',
  ];

  String? selectedCategory = 'All';

  List<String> sort = [
    'By Name',
    'By Rating',
  ];

  String? selectedSort = 'By Name';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // add search bar
          Container(
              margin: const EdgeInsets.all(10),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(children: [
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 40.0, // Adjust the height as needed
                        child: TextField(
                          controller: searchController,
                          style: const TextStyle(
                              fontSize:
                                  12.0), // Adjust the font size as needed
                          decoration: const InputDecoration(
                            hintText: 'Search',
                            border: InputBorder.none,
                          ),
                          onChanged: (value) {
                            setState(() {
                              touristSpots = getTouristSpotsWithSearch(
                                name: value,
                                category: selectedCategory,
                                sortBy: selectedSort,
                              );
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 40.0, // Adjust the height as needed
                        child: DropdownButtonFormField<String>(
                          style: const TextStyle(
                              color: Colors.black,
                              fontSize:
                                  12.0), // Adjust the font size as needed
                          decoration: const InputDecoration(
                            hintText: 'Category',
                            border: InputBorder.none,
                          ),
                          value: selectedCategory,
                          onChanged: (String? newValue) {
                            setState(() {
                              selectedCategory = newValue;
                              touristSpots = getTouristSpotsWithSearch(
                                name: searchController.text,
                                category: selectedCategory,
                                sortBy: selectedSort,
                              );
                            });
                          },
                          items: categories
                              .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 40.0, // Adjust the height as needed
                        child: DropdownButtonFormField<String>(
                          style: const TextStyle(
                              color: Colors.black,
                              fontSize:
                                  12.0), // Adjust the font size as needed
                          decoration: const InputDecoration(
                            hintText: 'Sort',
                            border: InputBorder.none,
                          ),
                          value: selectedSort,
                          onChanged: (String? newValue) {
                            setState(() {
                              selectedSort = newValue;
                              touristSpots = getTouristSpotsWithSearch(
                                name: searchController.text,
                                category: selectedCategory,
                                sortBy: selectedSort,
                              );
                            });
                          },
                          items: sort
                              .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ],
                ),
              ])),
          BusinessList(touristSpots: touristSpots),
        ],
      ),
    );
  }

  String owner = '';

  String getOwner() {
    SharedPreferencesHelper.getUserInfo().then((value) {
      setState(() {
        owner = value['uid'];
      });
    });
    return owner;
  }
}

// ignore: must_be_immutable
class BusinessList extends StatefulWidget {
  Future<List<dynamic>> touristSpots;

  BusinessList({Key? key, required this.touristSpots}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _BusinessListState createState() => _BusinessListState();
}

class _BusinessListState extends State<BusinessList> {
  TextEditingController nameController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController addressController = TextEditingController();

  Future<bool> validateImage(String imageUrl) async {
    try {
      final response = await http.head(Uri.parse(imageUrl));

      if (response.statusCode == 200) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: widget.touristSpots,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          // return Text('Error: ${snapshot.error}');
          if (snapshot.error is DioException) {
            final res = (snapshot.error as DioException).response;
            if (res?.statusCode == 401) {
              return const Center(
                child: Text('Unauthorized'),
              );
            } else if (res?.statusCode == 403) {
              return Center(
                child: Text(res?.data['detail']),
              );
            }
          }
          return const Center(
            child: Text('Failed to load tourist spots'),
          );
        } else {
          // Extract tourist spots data
          List<dynamic> touristSpotsData = snapshot.data!;
          // convert to list of cards
          return Expanded(
            child: ListView.builder(
              itemCount: touristSpotsData.length,
              itemBuilder: (context, index) {
                // Use a default image if 'image' is null or empty
                var image = touristSpotsData[index]['image'];
                bool isImageValid = true;
                // check if image is null or empty
                if (image == null || image == '') {
                  image = Vectors.defaultImage;
                  isImageValid = false;
                } else {
                  validateImage(image).then((value) {
                    if (!value) {
                      image = Vectors.defaultImage;
                      isImageValid = false;
                    }
                  });
                }
                Image imageWidget = isImageValid
                    ? Image.network(image)
                    : Image.asset(Vectors.defaultImage);
                return Card(
                  // add padding
                  margin: const EdgeInsets.only(
                    left: 10,
                    right: 10,
                    top: 10,
                    bottom: 5
                  ),
                  child: InkWell(
                    onTap: () {
                      _show_comments_and_ratings(
                          context, touristSpotsData[index]);
                    },
                    child: Column(
                      children: [
                        const SizedBox(height: 10),
                        Container(
                          height: 200,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: imageWidget.image,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        ListTile(
                          title: Text(touristSpotsData[index]['tourist_spot_name']),
                          subtitle: Text(touristSpotsData[index]['category']),
                          // put star and rating here
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                touristSpotsData[index]['average_rating']
                                    .toString(),
                                style: const TextStyle(
                                  color: Colors.orange,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              const Icon(
                                Icons.star,
                                color: Colors.orange,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        
        
        }
      },
    );
  }

  Map<String, dynamic> fieldErrors = {};

  // ignore: non_constant_identifier_names
  void _show_comments_and_ratings(BuildContext context, param1) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CommentsAndRatingsPage(data: param1),
      ),
    );
  }
}
