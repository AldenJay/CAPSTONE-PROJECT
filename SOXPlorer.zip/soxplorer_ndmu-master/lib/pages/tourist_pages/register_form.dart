import 'package:bottom_picker/bottom_picker.dart';
import 'package:bottom_picker/resources/arrays.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:soxplorer/components/app_text_form_field.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/utils/extensions.dart';

import 'package:soxplorer/values/app_constants.dart';

class RegisterFormTourist extends StatefulWidget {
  const RegisterFormTourist({super.key});

  @override
  State<RegisterFormTourist> createState() => _RegisterFormTouristState();
}

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _collection = _firestore.collection('user_info');

class _RegisterFormTouristState extends State<RegisterFormTourist> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController birthdayController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  bool isObscure = true;
  final _formKey = GlobalKey<FormState>();
  Map<String, dynamic> fieldErrors = {};

  final FirebaseAuth _auth = FirebaseAuth.instance;
  Future<dynamic> register() async {
    // convert to firebase auth
    try {
      UserCredential userCredential =
          await _auth.createUserWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text,
      );
      // add to firestore use user uid as reference
      _collection.doc(userCredential.user!.uid).set({
        'username': usernameController.text,
        'uid': userCredential.user!.uid,
        'birthday': birthdayController.text,
        'role': 'tourist',
      });
      return userCredential;
    } on FirebaseAuthException catch (e) {
      return e;
    }
  }

  void handleTouristRegister() {
    setState(() {
      fieldErrors = {};
    });
    register().then((response) {
      // clear fieldErrors
      setState(() {
        fieldErrors = {};
      });
      if (response is FirebaseAuthException) {
        setState(() {
          fieldErrors = {
            'email': response.code == 'invalid-email'
                ? 'Email is invalid'
                : response.code == 'email-already-in-use'
                    ? 'Email is already in use'
                    : response.code == 'missing-email'
                        ? 'Email is missing'
                        : null,
            'password': response.code == 'weak-password'
                ? 'Password is too weak'
                : response.code == 'missing-password'
                    ? 'Password is missing'
                    : null,
          };
        });
      } else {
        setState(() {
          fieldErrors = {};
        });
        // navigate to login page
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Registration successful'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.of(context).pushNamed('/login');
      }

      _formKey.currentState?.validate();
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = context.mediaQuerySize;
    return Scaffold(
        body: SingleChildScrollView(
            child: Column(children: [
      Container(
        height: size.height * 0.24,
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xff1E2E3D),
              Color(0xff152534),
              Color(0xff0C1C2E),
            ],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Register\nTourist Account',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(
              height: 6,
            ),
            Text(
              'Sign in to your Account to start exploring',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
      Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      const SizedBox(height: 16),
                      AppTextFormField(
                        labelText: 'Username',
                        controller: usernameController,
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your username'
                              : value.length < 3
                                  ? 'Username should be at least 3 characters'
                                  : null;
                        },
                      ),
                      AppTextFormField(
                        labelText: 'Email',
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: TextInputAction.next,
                        validator: (value) {
                          return fieldErrors.containsKey('email')
                              ? fieldErrors['email']
                              : AppConstants.emailRegex.hasMatch(value!)
                                  ? null
                                  : 'Please enter a valid email';
                        },
                        onChanged: (value) {
                          _formKey.currentState?.validate();
                        },
                      ),
                      AppTextFormField(
                          readOnly: true,
                          labelText: 'Birthday',
                          controller: birthdayController,
                          keyboardType: TextInputType.datetime,
                          textInputAction: TextInputAction.next,
                          validator: (value) {
                            return value == null || value.isEmpty
                                ? 'Please enter your birthday'
                                : null;
                          },
                          suffixIcon: Padding(
                            padding: const EdgeInsets.only(right: 15),
                            child: IconButton(
                              onPressed: () {
                                _openDatePicker(context);
                              },
                              style: ButtonStyle(
                                minimumSize: MaterialStateProperty.all(
                                  const Size(48, 48),
                                ),
                              ),
                              icon: const Icon(
                                Icons.calendar_today_outlined,
                                color: Colors.black,
                              ),
                            ),
                          )),
                      AppTextFormField(
                        labelText: 'Password',
                        keyboardType: TextInputType.visiblePassword,
                        textInputAction: TextInputAction.done,
                        controller: passwordController,
                        obscureText: isObscure,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your password'
                              : value.length < 6
                                  ? 'Password should be at least 6 characters'
                                  : fieldErrors.containsKey('password')
                                      ? fieldErrors['password']
                                      : null;
                        },
                        suffixIcon: Padding(
                          padding: const EdgeInsets.only(right: 15),
                          child: IconButton(
                            onPressed: () {
                              setState(() {
                                isObscure = !isObscure;
                              });
                            },
                            style: ButtonStyle(
                              minimumSize: MaterialStateProperty.all(
                                const Size(48, 48),
                              ),
                            ),
                            icon: Icon(
                              isObscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      AppTextFormField(
                        labelText: 'Confirm Password',
                        keyboardType: TextInputType.visiblePassword,
                        textInputAction: TextInputAction.done,
                        controller: confirmPasswordController,
                        obscureText: isObscure,
                        validator: (value) {
                          return value == null || value.isEmpty
                              ? 'Please enter your password'
                              : value != passwordController.text
                                  ? 'Passwords do not match'
                                  : null;
                        },
                        suffixIcon: Padding(
                          padding: const EdgeInsets.only(right: 15),
                          child: IconButton(
                            onPressed: () {
                              setState(() {
                                isObscure = !isObscure;
                              });
                            },
                            style: ButtonStyle(
                              minimumSize: MaterialStateProperty.all(
                                const Size(48, 48),
                              ),
                            ),
                            icon: Icon(
                              isObscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ),
                      // button
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: () {
                                setState(() {
                                  fieldErrors = {};
                                });
                                // check if form is not valid, show message
                                if (!_formKey.currentState!.validate()) {
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(const SnackBar(
                                    content: Text(
                                        'Please fill in all the required fields'),
                                    backgroundColor: Colors.red,
                                  ));
                                  return;
                                }
                                // check if password and confirm password match
                                if (passwordController.text !=
                                    confirmPasswordController.text) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                          'Passwords do not match. Please try again'),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                  return;
                                }
                                handleTouristRegister();
                              },
                              // change background color
                              style:
                                  Theme.of(context).outlinedButtonTheme.style,
                              icon: SvgPicture.asset(
                                Vectors.tourist,
                                width: 14,
                              ),
                              label: const Text(
                                'Register Account',
                                style: TextStyle(
                                    color: Color.fromARGB(255, 99, 33, 33)),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                )
              ]))
    ])));
  }

  void _openDatePicker(BuildContext context) {
    BottomPicker.date(
      title: 'Set your Birthday',
      dateOrder: DatePickerDateOrder.dmy,
      initialDateTime: DateTime(1996, 10, 22),
      maxDateTime: DateTime(2024),
      minDateTime: DateTime(1980),
      pickerTextStyle: const TextStyle(
        color: Colors.blue,
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
      titleStyle: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 15,
        color: Colors.blue,
      ),
      onSubmit: (date) {
        setState(() {
          birthdayController.text = date.toString().split(' ')[0];
        });
      },
      bottomPickerTheme: BottomPickerTheme.plumPlate,
    ).show(context);
  }
}
