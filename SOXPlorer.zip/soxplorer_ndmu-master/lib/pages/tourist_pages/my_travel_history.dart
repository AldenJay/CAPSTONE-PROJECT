import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:soxplorer/pages/business_owner_pages/reviews_ratings.dart';
import 'package:soxplorer/pages/business_owner_pages/tourist_spot_form.dart';
import 'package:soxplorer/pages/tourist_pages/travel_history_form.dart';
import 'package:soxplorer/resources/vectors.dart';
import 'package:soxplorer/shared/token.dart';

final FirebaseFirestore _firestore = FirebaseFirestore.instance;
// ignore: non_constant_identifier_names
final CollectionReference _travel_history =
    _firestore.collection('travel_history');

// ignore: must_be_immutable
class TravelHistory extends StatefulWidget {
  const TravelHistory({super.key});

  @override
  State<TravelHistory> createState() => _TravelHistoryState();
}

class _TravelHistoryState extends State<TravelHistory> {
  Future<List<dynamic>> touristSpots = Future<List<dynamic>>.value([]);

  Future<List<dynamic>> getTravelHistory() async {
    await Future.delayed(const Duration(seconds: 1));
    // use the collection reference to get all documents
    // filter the documents by the user
    QuerySnapshot querySnapshot =
        await _travel_history.where('tourist_username', isEqualTo: user).get();
    List<dynamic> response = [];
    for (var doc in querySnapshot.docs) {
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
      data['id'] = doc.id; // Add the document ID to the data
      response.add(data);
    }
    return response;
  }

  @override
  void initState() {
    super.initState();
    user = getUser();
    touristSpots = getTravelHistory();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: BusinessList(touristSpots: touristSpots),
      ),
    );
  }

  String user = '';

  String getUser() {
    SharedPreferencesHelper.getUserInfo().then(
      (value) => setState(() {
        user = value['username'];
      }),
    );
    return user;
  }
}

// ignore: must_be_immutable
class BusinessList extends StatefulWidget {
  Future<List<dynamic>> touristSpots;

  BusinessList({Key? key, required this.touristSpots}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _BusinessListState createState() => _BusinessListState();
}

class _BusinessListState extends State<BusinessList> {
  var dio = Dio();

  TextEditingController nameController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController addressController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
      future: widget.touristSpots,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          // return Text('Error: ${snapshot.error}');
          if (snapshot.error is DioException) {
            final res = (snapshot.error as DioException).response;
            if (res?.statusCode == 401) {
              return const Center(
                child: Text('Unauthorized'),
              );
            } else if (res?.statusCode == 403) {
              return Center(
                child: Text(res?.data['detail']),
              );
            }
          }
          return const Center(
            child: Text('Failed to load tourist spots'),
          );
        } else {
          return ListView.builder(
            itemCount: snapshot.data == null ? 0 : snapshot.data!.length,
            itemBuilder: (context, index) {
              var image = snapshot.data![index]['image'];
              // check if image is null or empty
              bool isUrl = true;
              if (image == null || image == '') {
                isUrl = false;
                image = Vectors.defaultImage;
              }
              return Card(
                child: ListTile(
                  // put image here
                  // leading: Image.network(
                  //   image,
                  //   width: 50,
                  //   height: 50,
                  // ),
                  // make it avatar
                  leading: CircleAvatar(
                    backgroundImage:
                        isUrl ? NetworkImage(image) : Image.asset(image).image,
                    maxRadius: 25,
                  ),
                  title: Text(snapshot.data![index]['tourist_spot_name']),
                  subtitle: Text(snapshot.data![index]['address']),
                  // add two action buttons
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TravelHistoryForm(
                                history: snapshot.data![index],
                              ),
                            ),
                          ).then((value) {
                            List<dynamic> touristSpots = snapshot.data!;
                            // find the index of the touristSpots
                            int index = touristSpots.indexWhere(
                                (element) => element['id'] == value['id']);
                            if (value['id'] != null) {
                              touristSpots[index] = {
                                'id': value['id'],
                                'tourist_spot_name': value['tourist_spot_name'],
                                'category': value['category'],
                                'description': value['description'],
                                'address': value['address'],
                                'image': value['image'],
                                'created': value['created'],
                                'tourist_spot': value['tourist_spot'],
                                'tourist_username': value['tourist_username'],
                              };
                              setState(() {
                                touristSpots = touristSpots;
                              });
                            }
                          });
                        },
                        icon: const Icon(
                          Icons.edit,
                          color: Color.fromARGB(255, 4, 198, 4),
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          _deleteDialogBuilder(
                              context, snapshot.data![index], snapshot);
                        },
                        icon: const Icon(
                          Icons.delete,
                          color: Color.fromARGB(255, 248, 4, 4),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }
      },
    );
  }

  Map<String, dynamic> fieldErrors = {};
  Future<Map<String, dynamic>> handleUpdateTouristSpot(data) async {
    try {
      await _travel_history.doc(data['id']).update({
        'description': data['description'],
      });

      // Fetch the updated data from Firestore
      final DocumentSnapshot updatedDoc =
          await _travel_history.doc(data['id']).get();
      Map<String, dynamic> result = updatedDoc.data() as Map<String, dynamic>;
      result['id'] = data['id'];
      return result;
    } catch (error) {
      return {'error': 'Something went wrong'};
    }
  }

  Future<bool> handleDeleteTouristSpot(data) {
    try {
      _travel_history.doc(data['id']).delete();
      return Future.value(true);
    } catch (error) {
      return Future.value(false);
    }
  }

  Future<void> _deleteDialogBuilder(
      BuildContext context, dynamic data, AsyncSnapshot<dynamic> snapshot) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            'Delete Journal Entry',
            style: TextStyle(
              color: Color.fromARGB(255, 99, 33, 33),
            ),
          ),
          content: Stack(children: <Widget>[
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Form(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Are you sure you want to delete ${data['name']}?',
                      style: const TextStyle(
                        color: Color.fromARGB(255, 99, 33, 33),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ]),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text(
                'Cancel',
                style: TextStyle(
                  color: Color.fromARGB(255, 25, 23, 23),
                ),
              ),
            ),
            TextButton(
              onPressed: () {
                // find the touristSpots based on the id
                List<dynamic> touristSpots = snapshot.data!;
                // find the index of the toursitSpot

                handleDeleteTouristSpot(data).then((value) {
                  if (value) {
                    // remove the toursitSpot
                    int index = touristSpots
                        .indexWhere((element) => element['id'] == data['id']);
                    touristSpots.removeAt(index);
                    // update the touristSpots
                    setState(() {
                      touristSpots = touristSpots;
                    });

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Entry deleted'),
                        backgroundColor: Colors.green,
                      ),
                    );
                    Navigator.of(context).pop();
                  }
                });
              },
              child: const Text(
                'Confirm',
                style: TextStyle(
                  color: Color.fromARGB(255, 99, 33, 33),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ignore: non_constant_identifier_names
  void _show_comments_and_ratings(BuildContext context, param1) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CommentsAndRatingsPage(data: param1),
      ),
    );
  }
}
