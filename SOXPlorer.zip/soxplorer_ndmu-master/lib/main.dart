import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:soxplorer/fbs.dart';
import 'package:soxplorer/pages/admin.dart';
import 'package:soxplorer/pages/business_owner.dart';
import 'package:soxplorer/pages/business_owner_pages/register_form.dart';
import 'package:soxplorer/pages/login_page.dart';
import 'package:soxplorer/pages/password_reset.dart';
import 'package:soxplorer/pages/tourist.dart';
import 'package:soxplorer/pages/tourist_pages/register_form.dart';
import 'package:soxplorer/values/app_constants.dart';
import 'package:soxplorer/values/app_routes.dart';
import 'package:soxplorer/values/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseService().initialize();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarIconBrightness: Brightness.light,
    ),
  );
  SystemChrome.setPreferredOrientations(
    [DeviceOrientation.portraitUp],
  ).then(
    (_) => runApp(
      const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Soxplorer',
      theme: AppTheme.themeData,
      initialRoute: AppRoutes.loginScreen,
      navigatorKey: AppConstants.navigationKey,
      routes: {
        AppRoutes.loginScreen: (context) => const LoginPage(),
        AppRoutes.touristScreen: (context) => const TouristPage(),
        AppRoutes.touristRegisterScreen: (context) =>
            const RegisterFormTourist(),
        AppRoutes.businessOwnerScreen: (context) => BusinessOwnerPage(),
        AppRoutes.businessOwnerRegisterScreen: (context) =>
            const RegisterFormBusinessOwner(),
        AppRoutes.adminScreen: (context) => const AdminPage(),
        AppRoutes.passwordResetScreen: (context) => const PasswordResetPage(),
      },
    );
  }
}
