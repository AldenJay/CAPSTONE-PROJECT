package com.example.soxplorer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
